import { Markup } from 'telegraf';

export const UI = {
  backHome: () => [
    [Markup.button.callback('🔙 Back', 'back'), Markup.button.callback('🏠 Home', 'home')]
  ],
  homeButton: () => [
    [Markup.button.callback('🏠 Home', 'home')]
  ],
  yesNo: (yesAction: string, noAction: string) => [
    [Markup.button.callback('✅ Yes', yesAction), Markup.button.callback('❌ No', noAction)]
  ],
};
