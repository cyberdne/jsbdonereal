import type { Context } from 'telegraf';
import { jasebBot } from '../bot';
import { userbotManager } from '../../userbots/userbot.manager';
import { targetManager } from '../../jaseb/target/target.manager';
import { linkScanner } from '../../jaseb/link.scanner';
import { jsonDb } from '../../storage/db';
import { sendMainMenu } from '../menus/main.menu';
import { sendUserbotsMenu } from '../menus/userbots.menu';
import { sendUserbotControlMenu } from '../menus/userbot.control.menu';
import { sendTargetsMenu } from '../menus/targets.menu';
import { sendStatsMenu } from '../menus/stats.menu';
import { sendTimerMenu } from '../menus/timer.menu';
import { sendPmPermitMenu } from '../menus/pmpermit.menu';
import { sendConfigMenu } from '../menus/config.menu';
import { sendSubscriptionMenu } from '../menus/subscription.menu';
import { sendGlobalSettingsMenu } from '../menus/global.settings.menu';
import { sendAutoPilotMenu } from '../menus/autopilot.menu';
import { sendAutoReplyMenu } from '../menus/autoreply.menu';
import { sendPremiumMenu } from '../menus/premium.menu';
import { sendSourceMenu } from '../menus/source.menu';
import { sendBackupMenu } from '../menus/backup.menu';
import { sendBotBroadcastMenu } from '../menus/bot.broadcast.menu';
import { jobRunner } from '../../jaseb/job.runner';
import { reportService } from '../../reports/report.service';
import { sourceService } from '../../services/source.service';
import { backupService } from '../../services/backup.service';
import { cacheService } from '../../services/cache.service';
import os from 'os';

export async function handleCallback(ctx: Context) {
    // @ts-ignore
    const data = ctx.callbackQuery?.data as string;
    if (!data) return;

    try {
        await ctx.answerCbQuery().catch(() => {});

        if (data === 'home') return sendMainMenu(ctx);
        if (data === 'noop') return;
        
        // ========== NAVIGATION MENUS ==========
        if (data.startsWith('menu:')) {
            const parts = data.split(':');
            const menu = parts[1];
            const arg = parts[2];

            switch(menu) {
                case 'userbots': return sendUserbotsMenu(ctx, arg ? parseInt(arg) : 1);
                case 'stats': return sendStatsMenu(ctx);
                case 'settings': return sendGlobalSettingsMenu(ctx);
                case 'targets': return sendTargetsMenu(ctx, arg);
                case 'timer': return sendTimerMenu(ctx, arg);
                case 'pmpermit': return sendPmPermitMenu(ctx, arg);
                case 'config': return sendConfigMenu(ctx, arg);
                case 'subscription': return sendSubscriptionMenu(ctx, arg);
                case 'autopilot': return sendAutoPilotMenu(ctx, arg);
                case 'autoreply': return sendAutoReplyMenu(ctx, arg);
                case 'premium': return sendPremiumMenu(ctx, arg);
                case 'source': return sendSourceMenu(ctx);
                case 'backup': return sendBackupMenu(ctx);
                case 'bot_broadcast': return sendBotBroadcastMenu(ctx);
                case 'add_userbot': 
                    const addKeyboard = {
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '📱 Login via Phone', callback_data: 'add:phone' }],
                                [{ text: '🔑 Tambah String Session', callback_data: 'add:session' }],
                                [{ text: '🔙 Kembali', callback_data: 'menu:userbots' }]
                            ]
                        }
                    };
                    await ctx.editMessageText(`<b>➕ Tambah Userbot</b>
━━━━━━━━━━━━━━━━━━━━━

Pilih metode untuk menambahkan userbot:

📱 <b>Login via Phone</b>
Masukkan nomor telepon dan kode OTP

🔑 <b>String Session</b>
Gunakan string session yang sudah ada

━━━━━━━━━━━━━━━━━━━━━`, { 
                        parse_mode: 'HTML', 
                        ...addKeyboard 
                    });
                    return;
                case 'set_reg_text':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_REG_TEXT', temp: { userbotId: arg } });
                    await ctx.reply('📝 <b>Set Regular Text</b>\n\nKirim teks yang akan di-broadcast.\nMendukung multi-line dan format Telegram.', { parse_mode: 'HTML' });
                    return;
                case 'set_fwd_text':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'AWAIT_FORWARD', temp: { userbotId: arg } });
                    await ctx.reply(`🔄 <b>Set Forward Message</b>
━━━━━━━━━━━━━━━━━━━━━

<b>Cara menggunakan:</b>
Forward pesan dari chat/channel mana saja ke sini.
Bot akan otomatis mendeteksi dan menyimpan pesan tersebut.

<i>💡 Bisa forward satu atau beberapa pesan sekaligus.</i>

━━━━━━━━━━━━━━━━━━━━━`, { parse_mode: 'HTML' });
                    return;
                case 'target_add':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'ADD_TARGET_MANUAL', temp: { userbotId: arg } });
                    await ctx.reply('🎯 Kirim link/username/ID target grup:\n\nContoh:\n• @groupname\n• t.me/groupname\n• -1001234567890');
                    return;
                case 'scan_channel':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SCAN_CHANNEL', temp: { userbotId: arg } });
                    await ctx.reply('📡 Kirim username channel untuk di-scan:\n\nContoh: @channelname atau t.me/channelname');
                    return;
                case 'search_group':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SEARCH_KEYWORD', temp: { userbotId: arg } });
                    await ctx.reply('🔍 Kirim keyword untuk mencari grup:\n\nContoh: crypto, trading, nft');
                    return;
            }
        }

        // ========== SOURCE CODE EXPORT ==========
        if (data.startsWith('source:')) {
            const mode = data.split(':')[1];
            
            if (mode === 'custom') {
                jasebBot.userStates.set(ctx.from!.id, { step: 'SOURCE_CUSTOM_NAME' });
                await ctx.reply('✏️ Kirim nama file (tanpa .zip):');
                return;
            }
            
            const validModes = ['script_only', 'no_modules', 'no_data', 'full'];
            if (validModes.includes(mode)) {
                await ctx.reply('⏳ Sedang membuat archive...');
                try {
                    const filePath = await sourceService.exportSource({ mode: mode as any });
                    await ctx.replyWithDocument({ source: filePath, filename: filePath.split('/').pop() });
                    await ctx.reply('✅ Export berhasil!');
                } catch (e: any) {
                    await ctx.reply(`❌ Gagal: ${e.message}`);
                }
                return sendSourceMenu(ctx);
            }
        }

        // ========== BACKUP ==========
        if (data.startsWith('backup:')) {
            const action = data.split(':')[1];
            
            switch(action) {
                case 'toggle':
                    const db = await jsonDb.read();
                    const current = (db as any).backupSettings?.enabled || false;
                    await backupService.updateSettings({ enabled: !current });
                    await ctx.reply(current ? '⏸️ Auto backup dinonaktifkan' : '▶️ Auto backup diaktifkan');
                    return sendBackupMenu(ctx);
                case 'set_channel':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_BACKUP_CHANNEL' });
                    await ctx.reply('📺 Kirim ID channel untuk backup:\n\nContoh: -1001234567890 atau @channelname');
                    return;
                case 'set_schedule':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_BACKUP_TIME' });
                    await ctx.reply('⏰ Kirim jam backup (format HH:MM):\n\nContoh: 00:00 atau 12:30');
                    return;
                case 'set_day':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_BACKUP_DAY' });
                    await ctx.reply('📅 Kirim hari backup:\n\n• * = Setiap hari\n• 1-31 = Tanggal tertentu\n\nContoh: * atau 1');
                    return;
                case 'now':
                    await ctx.reply('⏳ Membuat backup...');
                    try {
                        const backupPath = await backupService.createBackup();
                        await ctx.replyWithDocument({ source: backupPath, filename: backupPath.split('/').pop() });
                        await ctx.reply('✅ Backup berhasil!');
                    } catch (e: any) {
                        await ctx.reply(`❌ Gagal: ${e.message}`);
                    }
                    return sendBackupMenu(ctx);
                case 'restore':
                    const backups = await backupService.listBackups();
                    if (backups.length === 0) {
                        await ctx.reply('❌ Tidak ada backup tersedia');
                        return sendBackupMenu(ctx);
                    }
                    const latestPath = await backupService.getLatestBackup();
                    if (latestPath) {
                        await backupService.restoreBackup(latestPath);
                        await ctx.reply('✅ Restore berhasil dari backup terakhir!');
                    }
                    return sendBackupMenu(ctx);
            }
        }

        // ========== BOT BROADCAST ==========
        if (data.startsWith('botbc:')) {
            const parts = data.split(':');
            const action = parts[1];
            const arg = parts[2];

            switch(action) {
                case 'mode':
                    const db = await jsonDb.read();
                    (db as any).botBroadcast = (db as any).botBroadcast || { mode: 'CHANNEL', targets: [], message: null };
                    (db as any).botBroadcast.mode = arg;
                    await jsonDb.write(db);
                    await ctx.reply(`✅ Mode diubah ke ${arg}`);
                    return sendBotBroadcastMenu(ctx);
                case 'add_target':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'ADD_BC_TARGET' });
                    await ctx.reply('🎯 Kirim target (ID atau username):');
                    return;
                case 'set_message':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_BC_MESSAGE' });
                    await ctx.reply('📝 Kirim pesan untuk broadcast:');
                    return;
                case 'list_targets':
                    const dbList = await jsonDb.read();
                    const targets = (dbList as any).botBroadcast?.targets || [];
                    if (targets.length === 0) {
                        await ctx.reply('❌ Belum ada target');
                    } else {
                        await ctx.reply(`📋 <b>Daftar Target:</b>\n\n${targets.map((t: string, i: number) => `${i+1}. <code>${t}</code>`).join('\n')}`, { parse_mode: 'HTML' });
                    }
                    return;
                case 'clear_targets':
                    const dbClear = await jsonDb.read();
                    (dbClear as any).botBroadcast = (dbClear as any).botBroadcast || {};
                    (dbClear as any).botBroadcast.targets = [];
                    await jsonDb.write(dbClear);
                    await ctx.reply('✅ Targets dibersihkan');
                    return sendBotBroadcastMenu(ctx);
                case 'start':
                    await ctx.reply('⏳ Memulai broadcast...');
                    const dbBc = await jsonDb.read();
                    const bcSettings = (dbBc as any).botBroadcast;
                    if (!bcSettings?.message) {
                        await ctx.reply('❌ Pesan belum diset');
                        return;
                    }
                    if (!bcSettings?.targets?.length) {
                        await ctx.reply('❌ Target belum diset');
                        return;
                    }
                    let sent = 0;
                    for (const target of bcSettings.targets) {
                        try {
                            await ctx.telegram.sendMessage(target, bcSettings.message, { parse_mode: 'HTML' });
                            sent++;
                        } catch (e: any) {
                            // Skip failed
                        }
                    }
                    (dbBc as any).botBroadcast.lastBroadcastAt = Date.now();
                    await jsonDb.write(dbBc);
                    await ctx.reply(`✅ Broadcast selesai!\n\nTerkirim: ${sent}/${bcSettings.targets.length}`);
                    return sendBotBroadcastMenu(ctx);
            }
        }

        // ========== GLOBAL SETTINGS ==========
        if (data.startsWith('global:')) {
            const action = data.split(':')[1];
            
            switch(action) {
                case 'toggle_premium_emoji':
                    await jsonDb.updateGlobalSettings(s => {
                        s.defaultPremiumEmoji = !s.defaultPremiumEmoji;
                        return s;
                    });
                    return sendGlobalSettingsMenu(ctx);
                case 'clear_watermark':
                    await jsonDb.updateGlobalSettings(s => {
                        s.defaultWatermark = undefined;
                        return s;
                    });
                    return sendGlobalSettingsMenu(ctx);
                case 'clear_blacklist':
                    await jsonDb.updateGlobalSettings(s => {
                        s.globalBlacklist = [];
                        return s;
                    });
                    return sendGlobalSettingsMenu(ctx);
                case 'instant_delay':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_INSTANT_DELAY' });
                    await ctx.reply('⏱️ Masukkan delay instant loop (detik, min 60):');
                    return;
                case 'seq_delay':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_SEQ_DELAY' });
                    await ctx.reply('⏱️ Masukkan delay sequential (detik, min 5):');
                    return;
                case 'max_targets':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_MAX_TARGETS' });
                    await ctx.reply('🎯 Masukkan max target per userbot:');
                    return;
                case 'join_delay':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_JOIN_DELAY' });
                    await ctx.reply('⏱️ Masukkan delay auto join (ms, min 1000):');
                    return;
                case 'set_watermark':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_WATERMARK' });
                    await ctx.reply('📝 Masukkan teks watermark default:');
                    return;
                case 'add_blacklist':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_ADD_BLACKLIST' });
                    await ctx.reply('🚫 Masukkan chat ID untuk blacklist:');
                    return;
            }
        }

        // ========== AUTOPILOT ==========
        if (data.startsWith('autopilot:')) {
            const parts = data.split(':');
            const action = parts[1];
            const id = parts[2];

            switch(action) {
                case 'toggle':
                    await jsonDb.updateUserbot(id, u => {
                        if (!u.autoPilot) u.autoPilot = { enabled: false, scanLinks: false, autoJoin: false, joinedCount: 0, lastScanAt: 0 };
                        u.autoPilot.enabled = !u.autoPilot.enabled;
                        if (u.autoPilot.enabled) {
                            u.autoPilot.scanLinks = true;
                            u.autoPilot.autoJoin = true;
                        }
                        return u;
                    });
                    return sendAutoPilotMenu(ctx, id);
                case 'scan':
                    await jsonDb.updateUserbot(id, u => {
                        if (!u.autoPilot) u.autoPilot = { enabled: false, scanLinks: false, autoJoin: false, joinedCount: 0, lastScanAt: 0 };
                        u.autoPilot.scanLinks = !u.autoPilot.scanLinks;
                        return u;
                    });
                    return sendAutoPilotMenu(ctx, id);
                case 'join':
                    await jsonDb.updateUserbot(id, u => {
                        if (!u.autoPilot) u.autoPilot = { enabled: false, scanLinks: false, autoJoin: false, joinedCount: 0, lastScanAt: 0 };
                        u.autoPilot.autoJoin = !u.autoPilot.autoJoin;
                        return u;
                    });
                    return sendAutoPilotMenu(ctx, id);
                case 'reset':
                    await jsonDb.updateUserbot(id, u => {
                        if (u.autoPilot) {
                            u.autoPilot.joinedCount = 0;
                            u.autoPilot.lastScanAt = 0;
                        }
                        return u;
                    });
                    return sendAutoPilotMenu(ctx, id);
            }
        }

        // ========== AUTOREPLY ==========
        if (data.startsWith('autoreply:')) {
            const parts = data.split(':');
            const action = parts[1];
            const id = parts[2];

            switch(action) {
                case 'toggle':
                    await jsonDb.updateUserbot(id, u => {
                        if (!u.autoReplyKeyword) u.autoReplyKeyword = { enabled: false, keywords: [], useForward: false };
                        u.autoReplyKeyword.enabled = !u.autoReplyKeyword.enabled;
                        return u;
                    });
                    return sendAutoReplyMenu(ctx, id);
                case 'toggle_forward':
                    await jsonDb.updateUserbot(id, u => {
                        if (!u.autoReplyKeyword) u.autoReplyKeyword = { enabled: false, keywords: [], useForward: false };
                        u.autoReplyKeyword.useForward = !u.autoReplyKeyword.useForward;
                        return u;
                    });
                    return sendAutoReplyMenu(ctx, id);
                case 'clear_keywords':
                    await jsonDb.updateUserbot(id, u => {
                        if (u.autoReplyKeyword) u.autoReplyKeyword.keywords = [];
                        return u;
                    });
                    return sendAutoReplyMenu(ctx, id);
                case 'add_keyword':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'ADD_AUTOREPLY_KEYWORD', temp: { userbotId: id } });
                    await ctx.reply('💬 Masukkan keyword trigger:');
                    return;
                case 'set_text':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_AUTOREPLY_TEXT', temp: { userbotId: id } });
                    await ctx.reply('📝 Masukkan teks reply:');
                    return;
            }
        }

        // ========== PREMIUM ==========
        if (data.startsWith('premium:')) {
            const parts = data.split(':');
            const action = parts[1];
            const id = parts[2];

            if (action === 'toggle') {
                await jsonDb.updateUserbot(id, u => {
                    u.settings.premiumEmoji = !u.settings.premiumEmoji;
                    return u;
                });
                return sendPremiumMenu(ctx, id);
            }
        }

        // ========== ADD USERBOT METHODS ==========
        if (data.startsWith('add:')) {
            const method = data.split(':')[1];
            if (method === 'phone') {
                jasebBot.userStates.set(ctx.from!.id, { step: 'PHONE_LOGIN_NUMBER' });
                await ctx.reply('📱 Masukkan nomor telepon (format internasional):\n\nContoh: +628123456789');
            } else if (method === 'session') {
                jasebBot.userStates.set(ctx.from!.id, { step: 'ADD_SESSION_STRING' });
                await ctx.reply('🔑 Kirim string session GramJS/Telethon:');
            }
            return;
        }

        // ========== INPUT PROMPTS ==========
        if (data.startsWith('input:')) {
            const parts = data.split(':');
            const inputType = parts[1];
            const arg = parts[2];

            switch(inputType) {
                case 'timer_start':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_TIMER_START', temp: { userbotId: arg } });
                    await ctx.reply('⏰ Masukkan jam mulai (format HH:MM):\n\nContoh: 08:00');
                    break;
                case 'timer_stop':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_TIMER_STOP', temp: { userbotId: arg } });
                    await ctx.reply('⏰ Masukkan jam berhenti (format HH:MM):\n\nContoh: 22:00');
                    break;
                case 'pm_template':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_PM_TEMPLATE', temp: { userbotId: arg } });
                    await ctx.reply('📝 Masukkan template PM auto-reply:');
                    break;
                case 'pm_allow':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'ADD_PM_ALLOW', temp: { userbotId: arg } });
                    await ctx.reply('👤 Masukkan user ID yang diizinkan:');
                    break;
                case 'instant_delay':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_INSTANT_DELAY', temp: { userbotId: arg } });
                    await ctx.reply('⏱️ Masukkan delay instant loop (detik, min 60):');
                    break;
                case 'seq_delay':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_SEQ_DELAY', temp: { userbotId: arg } });
                    await ctx.reply('⏱️ Masukkan delay sequential (detik, min 5):');
                    break;
                case 'watermark':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_WATERMARK', temp: { userbotId: arg } });
                    await ctx.reply('📝 Masukkan teks watermark:');
                    break;
                case 'extend_sub':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'EXTEND_SUBSCRIPTION', temp: { userbotId: arg } });
                    await ctx.reply('📅 Masukkan jumlah hari perpanjangan:');
                    break;
            }
            return;
        }

        // ========== ACTIONS ==========
        if (data.startsWith('action:')) {
            const parts = data.split(':');
            const action = parts[1];
            const arg = parts[2];

            switch(action) {
                case 'start':
                    const dbStart = await jsonDb.read();
                    const ubStart = dbStart.userbots.find(u => u.id === arg);
                    if (!ubStart) return;

                    if (!ubStart.subscription.active || ubStart.subscription.expireAt < Date.now()) {
                        await ctx.reply('❌ Tidak bisa start: Subscription expired');
                        return sendUserbotControlMenu(ctx, arg);
                    }
                    if (ubStart.settings.targets.length === 0) {
                        await ctx.reply('❌ Tidak bisa start: Belum ada target');
                        return sendUserbotControlMenu(ctx, arg);
                    }
                    
                    const hasMessage = ubStart.settings.messageType === 'FORWARD'
                        ? (ubStart.settings.forwardedMessage?.messageIds?.length || ubStart.settings.forwardConfig?.messageIds?.length)
                        : !!ubStart.settings.regularText;
                    
                    if (!hasMessage) {
                        await ctx.reply('❌ Tidak bisa start: Belum ada pesan yang diset');
                        return sendUserbotControlMenu(ctx, arg);
                    }

                    await jsonDb.updateUserbot(arg, u => { u.status = 'RUNNING'; return u; });
                    await jobRunner.startJob(arg);
                    await ctx.reply('✅ Job Started!');
                    return sendUserbotControlMenu(ctx, arg);

                case 'stop':
                    await jsonDb.updateUserbot(arg, u => { u.status = 'STOPPED'; return u; });
                    await jobRunner.stopJob(arg);
                    await ctx.reply('⏹️ Job Stopped!');
                    return sendUserbotControlMenu(ctx, arg);

                case 'delete':
                    await userbotManager.stopClient(arg);
                    await jobRunner.stopJob(arg);
                    const dbDel = await jsonDb.read();
                    dbDel.userbots = dbDel.userbots.filter(u => u.id !== arg);
                    delete dbDel.jobs[arg];
                    await jsonDb.write(dbDel);
                    await ctx.reply('🗑️ Userbot Deleted!');
                    return sendUserbotsMenu(ctx);

                case 'scan_groups':
                    await ctx.reply('⏳ Scanning joined groups...');
                    const count = await targetManager.scanJoinedGroups(arg);
                    await ctx.reply(`✅ Ditambahkan ${count} grup baru ke target.`);
                    return sendTargetsMenu(ctx, arg);

                case 'clear_targets':
                    await targetManager.clearTargets(arg);
                    await ctx.reply('✅ Semua target dibersihkan.');
                    return sendTargetsMenu(ctx, arg);

                case 'toggle_timer':
                    await jsonDb.updateUserbot(arg, u => {
                        u.settings.timer.enabled = !u.settings.timer.enabled;
                        return u;
                    });
                    return sendTimerMenu(ctx, arg);

                case 'toggle_pmpermit':
                    await jsonDb.updateUserbot(arg, u => {
                        u.pmPermit.enabled = !u.pmPermit.enabled;
                        return u;
                    });
                    return sendPmPermitMenu(ctx, arg);

                case 'clear_pm_allowed':
                    await jsonDb.updateUserbot(arg, u => {
                        u.pmPermit.allowed = [];
                        return u;
                    });
                    return sendPmPermitMenu(ctx, arg);

                case 'toggle_msg_type':
                    await jsonDb.updateUserbot(arg, u => {
                        u.settings.messageType = u.settings.messageType === 'REGULAR' ? 'FORWARD' : 'REGULAR';
                        return u;
                    });
                    return sendConfigMenu(ctx, arg);

                case 'toggle_spread_mode':
                    await jsonDb.updateUserbot(arg, u => {
                        u.settings.spreadMode = u.settings.spreadMode === 'INSTANT' ? 'SEQUENTIAL' : 'INSTANT';
                        return u;
                    });
                    return sendConfigMenu(ctx, arg);

                case 'clear_watermark':
                    await jsonDb.updateUserbot(arg, u => {
                        u.settings.watermarkText = undefined;
                        return u;
                    });
                    return sendConfigMenu(ctx, arg);

                case 'toggle_resume_mode':
                    await jsonDb.updateUserbot(arg, u => {
                        u.subscription.resumeMode = u.subscription.resumeMode === 'RESUME' ? 'RESET' : 'RESUME';
                        return u;
                    });
                    return sendSubscriptionMenu(ctx, arg);

                case 'report':
                case 'report_generate':
                    await ctx.reply('⏳ Generating report...');
                    const path = await reportService.generateReport();
                    await ctx.replyWithDocument({ source: path, filename: 'jaseb_report.xlsx' });
                    return;

                case 'clear_cache':
                    await ctx.reply('🧹 Membersihkan cache & junk...');
                    const result = await cacheService.clearAll();
                    const freedMB = (result.totalFreed / 1024 / 1024).toFixed(2);
                    await ctx.reply(`✅ Selesai!\n\n• Cache dibersihkan: ${result.cacheCleared}\n• Junk dibersihkan: ${result.junkCleared}\n• Total dibebaskan: ${freedMB} MB`);
                    return sendMainMenu(ctx);

                case 'monitor_info':
                    const networkInterfaces = os.networkInterfaces();
                    let ips: string[] = [];
                    for (const [name, nets] of Object.entries(networkInterfaces)) {
                        for (const net of nets || []) {
                            if (net.family === 'IPv4' && !net.internal) {
                                ips.push(`${name}: ${net.address}`);
                            }
                        }
                    }
                    
                    const monitorText = `<b>🌐 Monitor URL Info</b>
━━━━━━━━━━━━━━━━━━━━━

<b>📡 Server Info</b>
├ Port: <code>5000</code>
├ Status: 🟢 Online
└ Hostname: <code>${os.hostname()}</code>

<b>🔗 Akses Monitor</b>
├ Internal: <code>http://localhost:5000</code>
└ Replit URL: <i>Lihat di tab Webview</i>

<b>📊 Network Interfaces</b>
${ips.map(ip => `└ ${ip}`).join('\n') || '└ Tidak tersedia'}

<b>💻 System</b>
├ Platform: ${os.platform()}
├ Uptime: ${Math.floor(os.uptime() / 3600)}h ${Math.floor((os.uptime() % 3600) / 60)}m
└ Memory: ${Math.floor(os.freemem() / 1024 / 1024)} MB free

━━━━━━━━━━━━━━━━━━━━━`;

                    await ctx.reply(monitorText, { parse_mode: 'HTML' });
                    return;
            }
        }

        // ========== DIRECT USERBOT SELECTION ==========
        if (data.startsWith('userbot:')) {
            const id = data.split(':')[1];
            return sendUserbotControlMenu(ctx, id);
        }

    } catch (e: any) {
        console.error('Callback error:', e);
        await ctx.reply(`❌ Error: ${e.message}`);
    }
}
