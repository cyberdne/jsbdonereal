import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendConfigMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const { settings } = userbot;
  
  const msgTypeIcon = settings.messageType === 'FORWARD' ? '🔄' : '📝';
  const modeIcon = settings.spreadMode === 'INSTANT' ? '⚡' : '🔁';

  const text = `<b>⚙️ Konfigurasi Broadcast</b>
━━━━━━━━━━━━━━━━━━━━━
Userbot: <b>${userbot.label}</b>

<b>📨 Tipe Pesan</b>
├ Mode: ${msgTypeIcon} <b>${settings.messageType}</b>
└ ${settings.messageType === 'FORWARD' ? 'Pesan akan di-forward' : 'Pesan teks biasa'}

<b>🚀 Mode Spread</b>
├ Mode: ${modeIcon} <b>${settings.spreadMode}</b>
└ ${settings.spreadMode === 'INSTANT' ? 'Kirim paralel ke semua target' : 'Kirim satu per satu'}

<b>⏱️ Pengaturan Delay</b>
├ Instant Loop: <b>${settings.delays.instantLoopDelaySec}s</b>
│   <i>(Jeda antar loop broadcast)</i>
└ Sequential: <b>${settings.delays.sequentialPerGroupDelaySec}s</b>
    <i>(Jeda antar pesan per grup)</i>

<b>📝 Watermark</b>
${settings.watermarkText ? `✅ Aktif: <code>${settings.watermarkText}</code>` : '❌ Tidak diset'}

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback(`${msgTypeIcon} ${settings.messageType}`, `action:toggle_msg_type:${id}`),
      Markup.button.callback(`${modeIcon} ${settings.spreadMode}`, `action:toggle_spread_mode:${id}`)
    ],
    [
      Markup.button.callback('⏱️ Instant Delay', `input:instant_delay:${id}`),
      Markup.button.callback('⏱️ Seq Delay', `input:seq_delay:${id}`)
    ],
    [
      Markup.button.callback('📝 Set Watermark', `input:watermark:${id}`),
      Markup.button.callback('🗑️ Hapus WM', `action:clear_watermark:${id}`)
    ],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
