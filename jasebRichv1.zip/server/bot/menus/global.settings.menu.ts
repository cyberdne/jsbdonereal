import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendGlobalSettingsMenu(ctx: Context) {
  const settings = await jsonDb.getGlobalSettings();

  const text = `<b>⚙️ Pengaturan Global</b>
━━━━━━━━━━━━━━━━━━━━━

<b>⏱️ Delay Default</b>
├ Instant Loop: <b>${settings.defaultInstantDelay}s</b>
├ Sequential: <b>${settings.defaultSequentialDelay}s</b>
└ Auto Join: <b>${settings.autoJoinDelay}ms</b>

<b>📝 Pesan</b>
├ Watermark: ${settings.defaultWatermark ? `<code>${settings.defaultWatermark.substring(0, 30)}...</code>` : '<i>Tidak diset</i>'}
└ Premium Emoji: ${settings.defaultPremiumEmoji ? '✅ Aktif' : '❌ Nonaktif'}

<b>🎯 Target</b>
├ Max per Userbot: <b>${settings.maxTargetsPerUserbot}</b>
└ Blacklist: <b>${settings.globalBlacklist.length}</b> chat

<b>🛡️ Anti-Spam</b>
├ Cooldown: <b>${settings.antiSpamCooldown}</b> join
└ FloodWait x: <b>${settings.floodWaitMultiplier}</b>

━━━━━━━━━━━━━━━━━━━━━
<i>Pengaturan ini berlaku untuk semua userbot.</i>`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback('⏱️ Instant Delay', 'global:instant_delay'),
      Markup.button.callback('⏱️ Seq Delay', 'global:seq_delay')
    ],
    [
      Markup.button.callback('🎯 Max Targets', 'global:max_targets'),
      Markup.button.callback('⏱️ Join Delay', 'global:join_delay')
    ],
    [
      Markup.button.callback('📝 Set Watermark', 'global:set_watermark'),
      Markup.button.callback('🗑️ Hapus WM', 'global:clear_watermark')
    ],
    [
      Markup.button.callback(settings.defaultPremiumEmoji ? '❌ Matikan Emoji' : '✨ Aktifkan Emoji', 'global:toggle_premium_emoji')
    ],
    [
      Markup.button.callback('➕ Add Blacklist', 'global:add_blacklist'),
      Markup.button.callback('🗑️ Clear BL', 'global:clear_blacklist')
    ],
    [Markup.button.callback('🔙 Kembali', 'home')]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
