import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';
import os from 'os';

export async function sendMainMenu(ctx: Context) {
  const db = await jsonDb.read();
  const totalUserbots = db.userbots.length;
  const activeUserbots = db.userbots.filter(u => u.status === 'RUNNING').length;
  const totalSent = db.userbots.reduce((sum, u) => sum + u.stats.sent, 0);
  
  const text = `<b>🚀 JASEB Control Panel</b>
━━━━━━━━━━━━━━━━━━━━━

<b>📊 Status Dashboard</b>
├ 🤖 Total Userbots: <b>${totalUserbots}</b>
├ ✅ Active Running: <b>${activeUserbots}</b>
├ 📨 Total Sent: <b>${totalSent.toLocaleString()}</b>
└ 💻 Server: <b>Online</b>

<b>ℹ️ Quick Info</b>
Kelola semua userbot broadcast Anda dari sini.
Gunakan menu di bawah untuk navigasi.

━━━━━━━━━━━━━━━━━━━━━
<i>JasebRich V2.1</i>`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback('🤖 Userbots', 'menu:userbots'),
      Markup.button.callback('📊 Statistik', 'menu:stats')
    ],
    [
      Markup.button.callback('⚙️ Pengaturan Global', 'menu:settings'),
      Markup.button.callback('📦 Report Excel', 'action:report')
    ],
    [
      Markup.button.callback('📢 Bot Broadcast', 'menu:bot_broadcast'),
      Markup.button.callback('💾 Backup & Restore', 'menu:backup')
    ],
    [
      Markup.button.callback('🧹 Clear Cache', 'action:clear_cache'),
      Markup.button.callback('📂 Source Code', 'menu:source')
    ],
    [
      Markup.button.callback('🌐 Monitor URL', 'action:monitor_info')
    ]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
