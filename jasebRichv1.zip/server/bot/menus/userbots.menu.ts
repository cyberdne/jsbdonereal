import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendUserbotsMenu(ctx: Context, page = 1) {
  const db = await jsonDb.read();
  const userbots = db.userbots;
  const perPage = 5;
  const totalPages = Math.max(1, Math.ceil(userbots.length / perPage));
  const currentPage = Math.min(Math.max(1, page), totalPages);
  const start = (currentPage - 1) * perPage;
  const pageUserbots = userbots.slice(start, start + perPage);

  const statusIcons: Record<string, string> = {
    'RUNNING': '🟢',
    'STOPPED': '⚪',
    'ERROR': '🔴',
    'OFF_SUBS': '⚠️'
  };

  let list = '';
  if (pageUserbots.length === 0) {
    list = '<i>Belum ada userbot. Tambahkan userbot pertama Anda!</i>';
  } else {
    list = pageUserbots.map((u, i) => {
      const icon = statusIcons[u.status] || '⚪';
      const daysLeft = Math.ceil((u.subscription.expireAt - Date.now()) / (24*60*60*1000));
      const subStatus = daysLeft > 0 ? `${daysLeft}d` : 'Expired';
      return `${start + i + 1}. ${icon} <b>${u.label}</b>\n    └ Buyer: <code>${u.buyerId}</code> | Sub: ${subStatus}`;
    }).join('\n\n');
  }

  const text = `<b>🤖 Daftar Userbots</b>
━━━━━━━━━━━━━━━━━━━━━

${list}

━━━━━━━━━━━━━━━━━━━━━
📄 Halaman ${currentPage}/${totalPages} • Total: ${userbots.length} userbot`;

  const rows: any[] = [];
  
  pageUserbots.forEach(u => {
    const icon = statusIcons[u.status] || '⚪';
    rows.push([Markup.button.callback(`${icon} ${u.label}`, `userbot:${u.id}`)]);
  });

  const navButtons = [];
  if (currentPage > 1) {
    navButtons.push(Markup.button.callback('⬅️ Prev', `menu:userbots:${currentPage - 1}`));
  }
  navButtons.push(Markup.button.callback(`📄 ${currentPage}/${totalPages}`, 'noop'));
  if (currentPage < totalPages) {
    navButtons.push(Markup.button.callback('➡️ Next', `menu:userbots:${currentPage + 1}`));
  }
  if (navButtons.length > 1 || totalPages > 1) {
    rows.push(navButtons);
  }

  rows.push([
    Markup.button.callback('➕ Tambah Userbot', 'menu:add_userbot'),
    Markup.button.callback('🔄 Refresh', 'menu:userbots')
  ]);
  rows.push([Markup.button.callback('🔙 Kembali', 'home')]);

  await safeEditOrResend(ctx, text, Markup.inlineKeyboard(rows));
}
