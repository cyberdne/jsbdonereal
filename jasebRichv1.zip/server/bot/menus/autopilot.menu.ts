import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendAutoPilotMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const autoPilot = userbot.autoPilot || { enabled: false, scanLinks: false, autoJoin: false, joinedCount: 0, lastScanAt: 0 };
  const lastScan = autoPilot.lastScanAt ? new Date(autoPilot.lastScanAt).toLocaleString('id-ID') : '-';

  const text = `<b>🚀 Auto Pilot Mode</b>
━━━━━━━━━━━━━━━━━━━━━
Userbot: <b>${userbot.label}</b>

<b>📊 Status</b>
├ Auto Pilot: ${autoPilot.enabled ? '✅ Aktif' : '❌ Nonaktif'}
├ Scan Links: ${autoPilot.scanLinks ? '✅' : '❌'}
└ Auto Join: ${autoPilot.autoJoin ? '✅' : '❌'}

<b>📈 Statistik</b>
├ Grup Joined: <b>${autoPilot.joinedCount}</b>
└ Last Scan: ${lastScan}

<b>📝 Cara Kerja Auto Pilot</b>
1. Broadcast pesan ke semua target
2. Scan chat target untuk link grup
3. Otomatis join grup baru yang ditemukan
4. Tambahkan ke target untuk BC berikutnya

<i>💡 Fitur ini sangat powerful untuk
memperluas jangkauan broadcast!</i>

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(autoPilot.enabled ? '⏸️ Nonaktifkan' : '▶️ Aktifkan', `autopilot:toggle:${id}`)],
    [
      Markup.button.callback(autoPilot.scanLinks ? '🔍 Scan: ON' : '🔍 Scan: OFF', `autopilot:scan:${id}`),
      Markup.button.callback(autoPilot.autoJoin ? '🔗 Join: ON' : '🔗 Join: OFF', `autopilot:join:${id}`)
    ],
    [Markup.button.callback('🔄 Reset Stats', `autopilot:reset:${id}`)],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
