import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendBotBroadcastMenu(ctx: Context) {
  const db = await jsonDb.read();
  const bcSettings = db.botBroadcast || {
    mode: 'CHANNEL',
    targets: [],
    message: null,
    lastBroadcastAt: null
  };
  
  const modeIcons: Record<string, string> = {
    'CHANNEL': '📢',
    'GROUP': '👥',
    'PM': '💬'
  };
  
  const text = `<b>📢 Bot Broadcast Manager</b>
━━━━━━━━━━━━━━━━━━━━━

<b>⚙️ Pengaturan Broadcast</b>
├ Mode: ${modeIcons[bcSettings.mode] || '📢'} <b>${bcSettings.mode}</b>
├ Total Targets: <b>${bcSettings.targets?.length || 0}</b>
├ Pesan: ${bcSettings.message ? '✅ Tersimpan' : '❌ Belum diset'}
└ Terakhir BC: ${bcSettings.lastBroadcastAt ? new Date(bcSettings.lastBroadcastAt).toLocaleString('id-ID') : '-'}

<b>📝 Cara Penggunaan</b>
1. Pilih mode broadcast (Channel/Group/PM)
2. Tambahkan target (ID atau username)
3. Set pesan yang akan dikirim
4. Klik "Mulai Broadcast"

<i>💡 Bot akan mengirim pesan ke semua target yang sudah diset.</i>

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback('📢 Channel', 'botbc:mode:CHANNEL'),
      Markup.button.callback('👥 Group', 'botbc:mode:GROUP'),
      Markup.button.callback('💬 PM', 'botbc:mode:PM')
    ],
    [
      Markup.button.callback('➕ Add Target', 'botbc:add_target'),
      Markup.button.callback('📋 List Targets', 'botbc:list_targets')
    ],
    [
      Markup.button.callback('✏️ Set Pesan', 'botbc:set_message'),
      Markup.button.callback('🗑️ Clear Targets', 'botbc:clear_targets')
    ],
    [Markup.button.callback('🚀 Mulai Broadcast', 'botbc:start')],
    [Markup.button.callback('🔙 Kembali', 'home')]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
