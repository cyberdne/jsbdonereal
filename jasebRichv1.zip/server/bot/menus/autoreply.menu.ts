import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendAutoReplyMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const autoReply = userbot.autoReplyKeyword || { enabled: false, keywords: [], useForward: false };

  const keywordList = autoReply.keywords.length > 0 
    ? autoReply.keywords.slice(0, 10).map((k, i) => `${i + 1}. <code>${k}</code>`).join('\n')
    : '<i>Belum ada keyword</i>';

  const text = `<b>💬 Auto Reply Keyword</b>
━━━━━━━━━━━━━━━━━━━━━
Userbot: <b>${userbot.label}</b>

<b>📊 Status</b>
├ Auto Reply: ${autoReply.enabled ? '✅ Aktif' : '❌ Nonaktif'}
└ Mode Reply: ${autoReply.useForward ? '🔄 Forward' : '📝 Teks'}

<b>🔑 Daftar Keywords</b>
${keywordList}

<b>📝 Teks Reply</b>
<code>${autoReply.replyText || '(Menggunakan pesan regular)'}</code>

<b>📋 Cara Kerja</b>
Ketika ada yang mengirim pesan
yang mengandung keyword, userbot
akan otomatis membalas.

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(autoReply.enabled ? '⏸️ Nonaktifkan' : '▶️ Aktifkan', `autoreply:toggle:${id}`)],
    [
      Markup.button.callback('➕ Add Keyword', `autoreply:add_keyword:${id}`),
      Markup.button.callback('🗑️ Clear KW', `autoreply:clear_keywords:${id}`)
    ],
    [
      Markup.button.callback('📝 Set Teks Reply', `autoreply:set_text:${id}`),
      Markup.button.callback(autoReply.useForward ? '📝 Pakai Teks' : '🔄 Pakai Forward', `autoreply:toggle_forward:${id}`)
    ],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
