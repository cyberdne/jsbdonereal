import type { Context } from 'telegraf';
import { Markup } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';
import { userbotManager } from '../../userbots/userbot.manager';

export async function sendStatsMenu(ctx: Context) {
  const db = await jsonDb.read();
  const userbots = db.userbots;
  
  const totalSent = userbots.reduce((acc, u) => acc + u.stats.sent, 0);
  const totalFailed = userbots.reduce((acc, u) => acc + u.stats.failed, 0);
  const totalSkipped = userbots.reduce((acc, u) => acc + u.stats.skipped, 0);
  const totalTargets = userbots.reduce((acc, u) => acc + u.settings.targets.length, 0);
  
  const statusCounts = {
    running: userbots.filter(u => u.status === 'RUNNING').length,
    stopped: userbots.filter(u => u.status === 'STOPPED').length,
    ready: userbots.filter(u => u.status === 'READY').length,
    error: userbots.filter(u => u.status === 'ERROR').length,
    offSubs: userbots.filter(u => u.status === 'OFF_SUBS').length,
  };

  const pingInfo: string[] = [];
  for (const u of userbots.slice(0, 5)) {
    const client = userbotManager.getClient(u.id);
    if (client) {
      try {
        const ping = await client.ping();
        pingInfo.push(`├ ${u.label}: <b>${ping}ms</b>`);
        await jsonDb.updateUserbot(u.id, ub => {
          ub.stats.lastPingMs = ping;
          return ub;
        });
      } catch (e) {
        pingInfo.push(`├ ${u.label}: <i>Error</i>`);
      }
    }
  }

  const text = `<b>📊 Statistik Sistem</b>
━━━━━━━━━━━━━━━━━━━━━

<b>🤖 Status Userbots</b>
├ Total: <b>${userbots.length}</b>
├ 🟢 Running: <b>${statusCounts.running}</b>
├ ⚪ Ready: <b>${statusCounts.ready}</b>
├ ⏹️ Stopped: <b>${statusCounts.stopped}</b>
├ ⚠️ Off Subs: <b>${statusCounts.offSubs}</b>
└ 🔴 Error: <b>${statusCounts.error}</b>

<b>📨 Statistik Pesan</b>
├ ✅ Terkirim: <b>${totalSent.toLocaleString()}</b>
├ ❌ Gagal: <b>${totalFailed.toLocaleString()}</b>
├ ⏭️ Dilewati: <b>${totalSkipped.toLocaleString()}</b>
└ 🎯 Total Target: <b>${totalTargets.toLocaleString()}</b>

<b>📡 Ping Userbots</b>
${pingInfo.length > 0 ? pingInfo.join('\n') + '\n└ ...' : '<i>Tidak ada userbot terkoneksi</i>'}

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('🔄 Refresh', 'menu:stats')],
    [Markup.button.callback('📥 Generate Excel Report', 'action:report_generate')],
    [Markup.button.callback('🔙 Kembali', 'home')]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
