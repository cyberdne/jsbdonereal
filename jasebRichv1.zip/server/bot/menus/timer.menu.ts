import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendTimerMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const { timer } = userbot.settings;

  const text = `<b>⏱️ Timer Scheduler</b>
━━━━━━━━━━━━━━━━━━━━━
Userbot: <b>${userbot.label}</b>

<b>📊 Status Timer</b>
├ Status: ${timer.enabled ? '✅ Aktif' : '❌ Nonaktif'}
├ Mulai: <b>${timer.startAt}</b>
└ Berhenti: <b>${timer.stopAt}</b>

<b>📝 Cara Kerja</b>
Bot akan otomatis:
• 🟢 Mulai job pada jam <b>${timer.startAt}</b>
• 🔴 Berhenti pada jam <b>${timer.stopAt}</b>

<i>⚠️ Menggunakan zona waktu server.</i>

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(timer.enabled ? '⏸️ Nonaktifkan' : '▶️ Aktifkan', `action:toggle_timer:${id}`)],
    [
      Markup.button.callback('🕐 Set Mulai', `input:timer_start:${id}`),
      Markup.button.callback('🕐 Set Berhenti', `input:timer_stop:${id}`)
    ],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
