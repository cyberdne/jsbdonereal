import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendUserbotControlMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);

  if (!userbot) {
    return ctx.answerCbQuery('Userbot tidak ditemukan');
  }

  const { status, subscription, settings, stats } = userbot;
  const isRunning = status === 'RUNNING';
  const isExpired = subscription.expireAt < Date.now();
  const daysLeft = Math.ceil((subscription.expireAt - Date.now()) / (24 * 60 * 60 * 1000));
  
  const statusIcons: Record<string, string> = {
    'RUNNING': '🟢 Berjalan',
    'STOPPED': '⚪ Berhenti',
    'ERROR': '🔴 Error',
    'OFF_SUBS': '⚠️ Expired'
  };
  
  const msgTypeIcon = settings.messageType === 'FORWARD' ? '🔄' : '📝';
  const hasMessage = settings.messageType === 'FORWARD' 
    ? (settings.forwardedMessage?.messageIds?.length || settings.forwardConfig?.messageIds?.length)
    : !!settings.regularText;
  
  const text = `<b>🎮 Panel Kontrol Userbot</b>
━━━━━━━━━━━━━━━━━━━━━

<b>📋 Informasi Dasar</b>
├ Label: <b>${userbot.label}</b>
├ Buyer ID: <code>${userbot.buyerId}</code>
├ Status: ${statusIcons[status] || '⚪ Unknown'}
└ Subscription: ${subscription.active && !isExpired ? `✅ ${daysLeft} hari lagi` : '❌ EXPIRED'}

<b>⚙️ Pengaturan Broadcast</b>
├ Tipe Pesan: ${msgTypeIcon} <b>${settings.messageType}</b>
├ Mode: <b>${settings.spreadMode}</b>
├ Pesan: ${hasMessage ? '✅ Tersedia' : '❌ Belum diset'}
├ Target: <b>${settings.targets.length}</b> grup
├ Timer: ${settings.timer.enabled ? `✅ ${settings.timer.startAt} - ${settings.timer.stopAt}` : '❌ Off'}
└ Watermark: ${settings.watermarkText ? '✅' : '❌'}

<b>✨ Fitur Premium</b>
├ Premium Emoji: ${settings.premiumEmoji ? '✅' : '❌'}
├ PM Permit: ${userbot.pmPermit.enabled ? '✅' : '❌'}
├ Auto Reply: ${userbot.autoReplyKeyword?.enabled ? '✅' : '❌'}
└ Auto Pilot: ${userbot.autoPilot?.enabled ? '✅' : '❌'}

<b>📊 Statistik</b>
├ Terkirim: <b>${stats.sent.toLocaleString()}</b>
├ Gagal: ${stats.failed}
├ Dilewati: ${stats.skipped}
└ Error: <i>${stats.lastError ? stats.lastError.substring(0, 40) + '...' : '-'}</i>

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback(isRunning ? '⏹️ Stop' : '▶️ Start', isRunning ? `action:stop:${id}` : `action:start:${id}`),
      Markup.button.callback('🔄 Refresh', `userbot:${id}`)
    ],
    [
      Markup.button.callback('📝 Set Regular Text', `menu:set_reg_text:${id}`),
      Markup.button.callback('🔄 Set Forward', `menu:set_fwd_text:${id}`)
    ],
    [
      Markup.button.callback('🎯 Target', `menu:targets:${id}`),
      Markup.button.callback('⏱️ Timer', `menu:timer:${id}`)
    ],
    [
      Markup.button.callback('⚙️ Config', `menu:config:${id}`),
      Markup.button.callback('🛡️ PM Permit', `menu:pmpermit:${id}`)
    ],
    [
      Markup.button.callback('💬 Auto Reply', `menu:autoreply:${id}`),
      Markup.button.callback('🚀 Auto Pilot', `menu:autopilot:${id}`)
    ],
    [
      Markup.button.callback('✨ Premium', `menu:premium:${id}`),
      Markup.button.callback('💳 Subscription', `menu:subscription:${id}`)
    ],
    [Markup.button.callback('🗑️ Hapus Userbot', `action:delete:${id}`)],
    [Markup.button.callback('🔙 Kembali', 'menu:userbots')]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
