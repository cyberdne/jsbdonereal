import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendTargetsMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const targets = userbot.settings.targets;
  const totalTargets = targets.length;
  const failedTargets = targets.filter(t => (t.failCount || 0) > 2).length;
  const recentTargets = targets.slice(-5).map((t, i) => {
    const failBadge = (t.failCount || 0) > 2 ? ' ⚠️' : '';
    return `${i + 1}. ${t.title || t.username || t.chatId}${failBadge}`;
  }).join('\n');

  const text = `<b>🎯 Target Manager</b>
━━━━━━━━━━━━━━━━━━━━━
Userbot: <b>${userbot.label}</b>

<b>📊 Statistik Target</b>
├ Total: <b>${totalTargets}</b> grup
├ Bermasalah: <b>${failedTargets}</b> grup
└ Limit: <b>${db.globalSettings?.maxTargetsPerUserbot || 500}</b>

<b>📋 Target Terbaru</b>
${recentTargets || '<i>Belum ada target</i>'}

<b>📝 Cara Menambah Target</b>
• Manual: Kirim link/username/ID
• Scan Groups: Scan dari grup yang sudah join
• Scan Channel: Extract link dari channel
• Search: Cari grup berdasarkan keyword

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('➕ Tambah Manual', `menu:target_add:${id}`)],
    [
      Markup.button.callback('🔍 Scan Groups', `action:scan_groups:${id}`),
      Markup.button.callback('📡 Scan Channel', `menu:scan_channel:${id}`)
    ],
    [Markup.button.callback('🔎 Search Keyword', `menu:search_group:${id}`)],
    [Markup.button.callback('🗑️ Hapus Semua', `action:clear_targets:${id}`)],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
