import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendSubscriptionMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const { subscription } = userbot;
  const now = Date.now();
  const isExpired = subscription.expireAt < now;
  const daysLeft = Math.ceil((subscription.expireAt - now) / (24 * 60 * 60 * 1000));
  const expireDate = new Date(subscription.expireAt).toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  const text = `<b>💳 Subscription Manager</b>
━━━━━━━━━━━━━━━━━━━━━
Userbot: <b>${userbot.label}</b>
Buyer ID: <code>${userbot.buyerId}</code>

<b>📊 Status Langganan</b>
├ Status: ${subscription.active && !isExpired ? '✅ Aktif' : '❌ Tidak Aktif'}
├ Berakhir: <b>${expireDate}</b>
├ Sisa: ${isExpired ? '⚠️ EXPIRED' : `<b>${daysLeft}</b> hari`}
└ Resume Mode: <b>${subscription.resumeMode}</b>

<b>📝 Resume Mode</b>
• <b>RESUME</b>: Lanjut dari posisi terakhir
• <b>RESET</b>: Mulai dari awal

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('➕ Perpanjang', `input:extend_sub:${id}`)],
    [Markup.button.callback(`🔄 Mode: ${subscription.resumeMode}`, `action:toggle_resume_mode:${id}`)],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
