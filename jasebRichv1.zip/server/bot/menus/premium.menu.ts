import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendPremiumMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const premiumEnabled = userbot.settings.premiumEmoji || false;

  const text = `<b>✨ Fitur Premium</b>
━━━━━━━━━━━━━━━━━━━━━
Userbot: <b>${userbot.label}</b>

<b>📊 Premium Emoji Support</b>
Status: ${premiumEnabled ? '✅ Aktif' : '❌ Nonaktif'}

<b>📋 Fitur yang Didapat</b>
• Support emoji premium Telegram
• Preserve format custom emoji saat forward
• Display emoji premium dengan benar

<b>⚠️ Catatan</b>
Fitur ini memerlukan akun userbot
berlangganan Telegram Premium
untuk fungsionalitas penuh.

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(premiumEnabled ? '❌ Nonaktifkan' : '✅ Aktifkan', `premium:toggle:${id}`)],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
