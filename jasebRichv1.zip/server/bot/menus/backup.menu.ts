import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendBackupMenu(ctx: Context) {
  const db = await jsonDb.read();
  const backupSettings = db.backupSettings || {
    enabled: false,
    channelId: null,
    schedule: { day: '*', hour: '00', minute: '00' }
  };
  
  const scheduleText = backupSettings.enabled 
    ? `Setiap ${backupSettings.schedule.day === '*' ? 'Hari' : 'Hari ke-' + backupSettings.schedule.day} pukul ${backupSettings.schedule.hour}:${backupSettings.schedule.minute}`
    : 'Tidak Aktif';
  
  const text = `<b>💾 Backup & Restore Manager</b>
━━━━━━━━━━━━━━━━━━━━━

<b>⚙️ Pengaturan Auto Backup</b>
├ Status: ${backupSettings.enabled ? '✅ Aktif' : '❌ Nonaktif'}
├ Channel: <code>${backupSettings.channelId || 'Belum diset'}</code>
└ Jadwal: ${scheduleText}

<b>📝 Deskripsi</b>
Auto backup akan mengirim file database
ke channel yang sudah diset sesuai jadwal.

<b>🔧 Aksi Manual:</b>
• Backup Now - Buat backup sekarang
• Restore - Pulihkan dari backup sebelumnya

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback(backupSettings.enabled ? '⏸️ Nonaktifkan' : '▶️ Aktifkan', 'backup:toggle'),
      Markup.button.callback('📺 Set Channel', 'backup:set_channel')
    ],
    [
      Markup.button.callback('⏰ Set Jadwal', 'backup:set_schedule'),
      Markup.button.callback('📅 Set Hari', 'backup:set_day')
    ],
    [
      Markup.button.callback('💾 Backup Now', 'backup:now'),
      Markup.button.callback('🔄 Restore', 'backup:restore')
    ],
    [Markup.button.callback('🔙 Kembali', 'home')]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
