import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';

export async function sendSourceMenu(ctx: Context) {
  const text = `<b>📂 Source Code Manager</b>
━━━━━━━━━━━━━━━━━━━━━

<b>📦 Export Script Bot</b>
Backup source code bot ini ke file ZIP.
Pilih opsi sesuai kebutuhan Anda:

<b>Opsi Export:</b>
├ 🔹 <b>Script Only</b> - Hanya file inti
│    (tanpa node_modules & data)
├ 🔹 <b>Tanpa Modules</b> - Script + data
│    (tanpa node_modules saja)
├ 🔹 <b>Tanpa Data</b> - Script + modules
│    (tanpa folder data)
└ 🔹 <b>Full Backup</b> - Semua file

<i>⚠️ File akan dikirim ke chat ini setelah proses selesai.</i>

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('📄 Script Only', 'source:script_only')],
    [Markup.button.callback('📁 Tanpa Modules', 'source:no_modules')],
    [Markup.button.callback('💾 Tanpa Data', 'source:no_data')],
    [Markup.button.callback('📦 Full Backup', 'source:full')],
    [Markup.button.callback('✏️ Custom Name', 'source:custom')],
    [Markup.button.callback('🔙 Kembali', 'home')]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
