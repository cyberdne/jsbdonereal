import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { jsonDb } from '../../storage/db';

export async function sendPmPermitMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const { pmPermit } = userbot;

  const text = `<b>🛡️ PM Permit Manager</b>
━━━━━━━━━━━━━━━━━━━━━
Userbot: <b>${userbot.label}</b>

<b>📊 Status</b>
├ PM Permit: ${pmPermit.enabled ? '✅ Aktif' : '❌ Nonaktif'}
└ Whitelist: <b>${pmPermit.allowed.length}</b> user

<b>📝 Template Balasan</b>
<code>${pmPermit.template || '(Belum diset)'}</code>

<b>📋 Cara Kerja</b>
Saat aktif, userbot akan otomatis
membalas PM dari orang yang tidak
ada di whitelist dengan template.

━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(pmPermit.enabled ? '⏸️ Nonaktifkan' : '▶️ Aktifkan', `action:toggle_pmpermit:${id}`)],
    [Markup.button.callback('📝 Set Template', `input:pm_template:${id}`)],
    [
      Markup.button.callback('➕ Tambah User', `input:pm_allow:${id}`),
      Markup.button.callback('🗑️ Clear WL', `action:clear_pm_allowed:${id}`)
    ],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
