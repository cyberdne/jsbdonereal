import fs from 'fs-extra';
import path from 'path';
import { ENV } from '../config/env';
import { jsonDb } from '../storage/db';
import pino from 'pino';
import * as cron from 'node-cron';

const logger = pino({ level: 'info' });

export interface BackupSettings {
  enabled: boolean;
  channelId: string | null;
  schedule: {
    day: string;
    hour: string;
    minute: string;
  };
}

export class BackupService {
  private readonly backupDir = path.join(ENV.DATA_DIR, 'backups');
  private cronJob: cron.ScheduledTask | null = null;

  async init(): Promise<void> {
    await fs.ensureDir(this.backupDir);
    await this.scheduleAutoBackup();
  }

  async createBackup(): Promise<string> {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
    const filename = `backup_${timestamp}.json`;
    const backupPath = path.join(this.backupDir, filename);

    const db = await jsonDb.read();
    await fs.writeJSON(backupPath, db, { spaces: 2 });
    
    logger.info(`Backup created: ${filename}`);
    return backupPath;
  }

  async restoreBackup(backupPath: string): Promise<boolean> {
    try {
      if (!await fs.pathExists(backupPath)) {
        throw new Error('Backup file not found');
      }

      const backupData = await fs.readJSON(backupPath);
      await jsonDb.write(backupData);
      
      logger.info(`Backup restored from: ${backupPath}`);
      return true;
    } catch (error: any) {
      logger.error(`Restore failed: ${error.message}`);
      throw error;
    }
  }

  async listBackups(): Promise<{ name: string; date: Date; size: number }[]> {
    await fs.ensureDir(this.backupDir);
    const files = await fs.readdir(this.backupDir);
    const backups = [];

    for (const file of files) {
      if (file.endsWith('.json')) {
        const filePath = path.join(this.backupDir, file);
        const stats = await fs.stat(filePath);
        backups.push({
          name: file,
          date: stats.mtime,
          size: stats.size
        });
      }
    }

    return backups.sort((a, b) => b.date.getTime() - a.date.getTime());
  }

  async getLatestBackup(): Promise<string | null> {
    const backups = await this.listBackups();
    if (backups.length === 0) return null;
    return path.join(this.backupDir, backups[0].name);
  }

  async scheduleAutoBackup(): Promise<void> {
    const db = await jsonDb.read();
    const settings = (db as any).backupSettings as BackupSettings | undefined;
    
    if (!settings?.enabled) {
      if (this.cronJob) {
        this.cronJob.stop();
        this.cronJob = null;
      }
      return;
    }

    const { day, hour, minute } = settings.schedule;
    const cronExpr = day === '*' 
      ? `${minute} ${hour} * * *`
      : `${minute} ${hour} ${day} * *`;

    if (this.cronJob) {
      this.cronJob.stop();
    }

    this.cronJob = cron.schedule(cronExpr, async () => {
      try {
        const backupPath = await this.createBackup();
        logger.info(`Auto backup completed: ${backupPath}`);
        // Send to channel if configured
        if (settings.channelId) {
          // This will be handled by the bot
        }
      } catch (error: any) {
        logger.error(`Auto backup failed: ${error.message}`);
      }
    });

    logger.info(`Auto backup scheduled: ${cronExpr}`);
  }

  async updateSettings(settings: Partial<BackupSettings>): Promise<void> {
    const db = await jsonDb.read();
    (db as any).backupSettings = {
      ...(db as any).backupSettings,
      ...settings
    };
    await jsonDb.write(db);
    await this.scheduleAutoBackup();
  }

  async clearOldBackups(keepCount = 10): Promise<number> {
    const backups = await this.listBackups();
    let deletedCount = 0;

    if (backups.length > keepCount) {
      const toDelete = backups.slice(keepCount);
      for (const backup of toDelete) {
        await fs.remove(path.join(this.backupDir, backup.name));
        deletedCount++;
      }
    }

    return deletedCount;
  }
}

export const backupService = new BackupService();
