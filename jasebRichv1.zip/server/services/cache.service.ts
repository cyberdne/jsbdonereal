import fs from 'fs-extra';
import path from 'path';
import pino from 'pino';

const logger = pino({ level: 'info' });

export class CacheService {
  private readonly projectRoot = process.cwd();
  
  private readonly cachePaths = [
    '.cache',
    'temp',
    '.vite',
    'node_modules/.cache',
    'node_modules/.vite'
  ];
  
  private readonly junkPatterns = [
    '*.log',
    '*.tmp',
    '.DS_Store',
    'Thumbs.db',
    '*.swp',
    '*.swo'
  ];

  async clearCache(): Promise<{ cleared: number; freedBytes: number }> {
    let cleared = 0;
    let freedBytes = 0;

    for (const cachePath of this.cachePaths) {
      const fullPath = path.join(this.projectRoot, cachePath);
      try {
        if (await fs.pathExists(fullPath)) {
          const stats = await this.getDirSize(fullPath);
          await fs.remove(fullPath);
          cleared++;
          freedBytes += stats;
          logger.info(`Cleared cache: ${cachePath} (${this.formatBytes(stats)})`);
        }
      } catch (error: any) {
        logger.error(`Failed to clear ${cachePath}: ${error.message}`);
      }
    }

    return { cleared, freedBytes };
  }

  async clearJunk(): Promise<{ cleared: number; freedBytes: number }> {
    let cleared = 0;
    let freedBytes = 0;

    const walkDir = async (dir: string) => {
      try {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        
        for (const entry of entries) {
          const fullPath = path.join(dir, entry.name);
          
          // Skip node_modules and .git
          if (entry.name === 'node_modules' || entry.name === '.git') continue;
          
          if (entry.isDirectory()) {
            await walkDir(fullPath);
          } else {
            for (const pattern of this.junkPatterns) {
              const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$');
              if (regex.test(entry.name)) {
                try {
                  const stats = await fs.stat(fullPath);
                  await fs.remove(fullPath);
                  cleared++;
                  freedBytes += stats.size;
                } catch (e) {
                  // Ignore errors
                }
              }
            }
          }
        }
      } catch (error) {
        // Ignore errors
      }
    };

    await walkDir(this.projectRoot);
    logger.info(`Cleared ${cleared} junk files (${this.formatBytes(freedBytes)})`);
    
    return { cleared, freedBytes };
  }

  async clearAll(): Promise<{ cacheCleared: number; junkCleared: number; totalFreed: number }> {
    const cacheResult = await this.clearCache();
    const junkResult = await this.clearJunk();
    
    return {
      cacheCleared: cacheResult.cleared,
      junkCleared: junkResult.cleared,
      totalFreed: cacheResult.freedBytes + junkResult.freedBytes
    };
  }

  private async getDirSize(dir: string): Promise<number> {
    let size = 0;
    try {
      const entries = await fs.readdir(dir, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          size += await this.getDirSize(fullPath);
        } else {
          const stats = await fs.stat(fullPath);
          size += stats.size;
        }
      }
    } catch (e) {
      // Ignore errors
    }
    return size;
  }

  private formatBytes(bytes: number): string {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }
}

export const cacheService = new CacheService();
