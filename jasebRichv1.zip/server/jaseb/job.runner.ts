import { Api } from 'telegram';
import { userbotManager } from '../userbots/userbot.manager';
import { jsonDb } from '../storage/db';
import { linkScanner } from './link.scanner';
import pino from 'pino';

const logger = pino({ level: 'info' });

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

export class JobRunner {
  private activeJobs = new Map<string, boolean>();
  private jobQueues = new Map<string, Promise<void>>();

  async startJob(userbotId: string) {
    if (this.activeJobs.get(userbotId)) return;
    this.activeJobs.set(userbotId, true);
    
    const jobPromise = this.runLoop(userbotId).catch(e => {
      logger.error(`Job ${userbotId} crashed: ${e?.message}`);
      this.activeJobs.delete(userbotId);
      jsonDb.updateUserbot(userbotId, u => { 
        u.status = 'ERROR'; 
        u.stats.lastError = e?.message || 'Unknown error';
        return u; 
      });
    });
    
    this.jobQueues.set(userbotId, jobPromise);
  }

  async stopJob(userbotId: string) {
    this.activeJobs.set(userbotId, false);
    this.activeJobs.delete(userbotId);
  }

  isRunning(userbotId: string) {
    return this.activeJobs.get(userbotId) === true;
  }

  private async runLoop(userbotId: string) {
    logger.info(`Starting job loop for ${userbotId}`);
    
    while (this.activeJobs.get(userbotId)) {
      const db = await jsonDb.read();
      const userbot = db.userbots.find(u => u.id === userbotId);
      const globalSettings = db.globalSettings;
       
      if (!userbot) {
        this.activeJobs.delete(userbotId);
        break;
      }

      // Check subscription
      if (!userbot.subscription.active || userbot.subscription.expireAt < Date.now()) {
        logger.info(`Subscription expired for ${userbot.label}, stopping job`);
        await jsonDb.updateUserbot(userbotId, u => {
          u.status = 'OFF_SUBS';
          u.subscription.autoOffApplied = true;
          return u;
        });
        this.activeJobs.delete(userbotId);
        break;
      }

      if (userbot.status !== 'RUNNING') {
        this.activeJobs.delete(userbotId);
        break;
      }

      const gramClient = userbotManager.getClient(userbotId);
      if (!gramClient) {
        logger.warn(`Client not found for ${userbotId}, attempting reconnect...`);
        try {
          await userbotManager.startClient(userbotId);
          await sleep(2000);
        } catch (e: any) {
          logger.error(`Failed to reconnect ${userbotId}: ${e?.message}`);
          this.activeJobs.delete(userbotId);
          await jsonDb.updateUserbot(userbotId, u => { u.status = 'ERROR'; return u; });
          break;
        }
        continue;
      }

      // Auto Pilot - Scan links from targets if enabled
      if (userbot.autoPilot?.enabled && userbot.autoPilot?.scanLinks) {
        try {
          const newCount = await linkScanner.scanAndJoinFromTargets(userbotId);
          if (newCount > 0) {
            logger.info(`AutoPilot: Joined ${newCount} new groups for ${userbot.label}`);
          }
        } catch (e: any) {
          logger.error(`AutoPilot scan error: ${e?.message}`);
        }
      }

      // --- BROADCAST LOGIC ---
      const targets = userbot.settings.targets;
      const blacklist = [...(userbot.settings.blacklist || []), ...(globalSettings?.globalBlacklist || [])];
      
      // Process targets with optimized batching
      const batchSize = userbot.settings.spreadMode === 'INSTANT' ? 10 : 1;
      
      for (let i = 0; i < targets.length; i += batchSize) {
        if (!this.activeJobs.get(userbotId)) break;
        
        const batch = targets.slice(i, i + batchSize);
        
        // Process batch
        const promises = batch.map(async (target) => {
          if (blacklist.includes(target.chatId)) return;
          
          try {
            let entity: any;
            try {
              entity = await gramClient.client.getEntity(target.chatId);
            } catch {
              if (target.username) {
                entity = await gramClient.client.getEntity(target.username);
              } else {
                throw new Error('Cannot resolve entity');
              }
            }
            
            // Determine message type and send
            if (userbot.settings.messageType === 'FORWARD' && userbot.settings.forwardedMessage) {
              await this.sendForwardMessage(gramClient, userbot, entity);
            } else if (userbot.settings.messageType === 'FORWARD' && userbot.settings.forwardConfig?.chatId) {
              await this.sendForwardFromConfig(gramClient, userbot, entity);
            } else {
              await this.sendRegularMessage(gramClient, userbot, entity, globalSettings);
            }

            await jsonDb.updateUserbot(userbotId, u => {
              u.stats.sent += 1;
              u.stats.lastRunAt = Date.now();
              const t = u.settings.targets.find(x => x.chatId === target.chatId);
              if (t) t.lastSentAt = Date.now();
              return u;
            });

          } catch (e: any) {
            await this.handleSendError(e, userbotId, target.chatId);
          }
        });
        
        if (userbot.settings.spreadMode === 'INSTANT') {
          await Promise.allSettled(promises);
        } else {
          for (const p of promises) {
            await p;
            const seqDelay = Math.max(userbot.settings.delays.sequentialPerGroupDelaySec, 5);
            await sleep(seqDelay * 1000);
          }
        }

        // Small delay between batches
        if (userbot.settings.spreadMode === 'INSTANT') {
          await sleep(500);
        }
      }

      // Loop delay
      const loopDelaySec = Math.max(userbot.settings.delays.instantLoopDelaySec, 60);
      const loopDelay = userbot.settings.spreadMode === 'INSTANT' ? loopDelaySec * 1000 : 10000;
      
      await sleep(loopDelay);
    }
    
    logger.info(`Job loop for ${userbotId} stopped`);
  }

  private async sendForwardMessage(client: any, userbot: any, targetEntity: any) {
    const fwdMsg = userbot.settings.forwardedMessage;
    
    if (fwdMsg?.chatId && fwdMsg?.messageIds?.length > 0) {
      try {
        const fromEntity = await client.client.getEntity(fwdMsg.chatId);
        await client.client.forwardMessages(targetEntity, {
          messages: fwdMsg.messageIds,
          fromPeer: fromEntity
        });
        return;
      } catch (e: any) {
        logger.error(`Forward error: ${e?.message}`);
        throw e;
      }
    }
    
    throw new Error('No forwarded message configured');
  }

  private async sendForwardFromConfig(client: any, userbot: any, targetEntity: any) {
    const config = userbot.settings.forwardConfig;
    
    if (config?.chatId && config?.messageIds?.length > 0) {
      try {
        const fromEntity = await client.client.getEntity(config.chatId);
        await client.client.forwardMessages(targetEntity, {
          messages: config.messageIds,
          fromPeer: fromEntity
        });
        return;
      } catch (e: any) {
        logger.error(`Forward config error: ${e?.message}`);
        throw e;
      }
    }
    
    throw new Error('No forward config');
  }

  private async sendRegularMessage(client: any, userbot: any, targetEntity: any, globalSettings: any) {
    let text = userbot.settings.regularText || '';
    
    if (!text) {
      throw new Error('No regular text configured');
    }
    
    const watermark = userbot.settings.watermarkText || globalSettings?.defaultWatermark;
    const message = this.buildMessage(text, watermark);
    
    if (userbot.settings.premiumEmoji || globalSettings?.defaultPremiumEmoji) {
      await client.client.sendMessage(targetEntity, { 
        message,
        parseMode: 'html'
      });
    } else {
      await client.client.sendMessage(targetEntity, { message });
    }
  }

  private async handleSendError(e: any, userbotId: string, targetChatId: string) {
    logger.error(`Failed to send to ${targetChatId}: ${e?.message}`);
    
    if (e.message?.includes('FLOOD_WAIT') || e.seconds) {
      const waitTime = e.seconds || parseInt(e.message.match(/\d+/)?.[0] || '60');
      logger.warn(`FloodWait: Waiting ${waitTime} seconds...`);
      await sleep(waitTime * 1000);
      return;
    }
    
    if (e.message?.includes('CHAT_WRITE_FORBIDDEN') || 
        e.message?.includes('USER_BANNED') ||
        e.message?.includes('CHANNEL_PRIVATE')) {
      await jsonDb.updateUserbot(userbotId, u => {
        u.stats.skipped += 1;
        const t = u.settings.targets.find(x => x.chatId === targetChatId);
        if (t) t.failCount = (t.failCount || 0) + 1;
        return u;
      });
    } else {
      await jsonDb.updateUserbot(userbotId, u => {
        u.stats.failed += 1;
        u.stats.lastError = e?.message?.substring(0, 100);
        return u;
      });
    }
  }

  private buildMessage(text: string, watermark?: string): string {
    if (!watermark) return text;
    return `${text}\n\n${watermark}`;
  }
}

export const jobRunner = new JobRunner();
