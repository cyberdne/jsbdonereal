import { Api } from 'telegram';
import { userbotManager } from '../userbots/userbot.manager';
import { jsonDb } from '../storage/db';
import pino from 'pino';

const logger = pino({ level: 'info' });
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

// Comprehensive Telegram link patterns
const TELEGRAM_LINK_PATTERNS = [
  // Standard public links: t.me/username or t.me/channelname
  /(?:https?:\/\/)?(?:www\.)?t\.me\/([a-zA-Z][a-zA-Z0-9_]{3,31})(?:\/\d+)?/gi,
  // telegram.me links
  /(?:https?:\/\/)?(?:www\.)?telegram\.me\/([a-zA-Z][a-zA-Z0-9_]{3,31})(?:\/\d+)?/gi,
  // Private invite links: t.me/joinchat/HASH
  /(?:https?:\/\/)?(?:www\.)?t\.me\/joinchat\/([a-zA-Z0-9_-]+)/gi,
  // New format invite: t.me/+HASH
  /(?:https?:\/\/)?(?:www\.)?t\.me\/\+([a-zA-Z0-9_-]+)/gi,
  // telegram.dog links
  /(?:https?:\/\/)?(?:www\.)?telegram\.dog\/([a-zA-Z][a-zA-Z0-9_]{3,31})/gi,
];

// Words to filter out (not groups)
const EXCLUDED_USERNAMES = new Set([
  'joinchat', 'addstickers', 'addemoji', 'share', 'proxy', 'socks', 
  'iv', 'bg', 'setlanguage', 'addtheme', 'confirmphone', 'login',
  'boost', 'giftcode', 'premium', 'invoice'
]);

export class LinkScanner {

  private extractLinksFromText(text: string): { type: 'username' | 'invite', value: string }[] {
    const results: { type: 'username' | 'invite', value: string }[] = [];
    const seen = new Set<string>();

    for (const pattern of TELEGRAM_LINK_PATTERNS) {
      pattern.lastIndex = 0; // Reset regex
      let match;
      while ((match = pattern.exec(text)) !== null) {
        const value = match[1];
        if (!value || seen.has(value.toLowerCase())) continue;
        
        // Check if it's an invite hash or username
        const isInvite = pattern.source.includes('joinchat') || 
                        pattern.source.includes('\\+') ||
                        value.length > 20;
        
        if (!isInvite && EXCLUDED_USERNAMES.has(value.toLowerCase())) continue;
        
        seen.add(value.toLowerCase());
        results.push({
          type: isInvite ? 'invite' : 'username',
          value
        });
      }
    }

    return results;
  }

  async scanAndJoinFromTargets(userbotId: string): Promise<number> {
    const db = await jsonDb.read();
    const userbot = db.userbots.find(u => u.id === userbotId);
    if (!userbot) return 0;

    const client = userbotManager.getClient(userbotId);
    if (!client) return 0;

    const globalSettings = db.globalSettings;
    const joinDelay = globalSettings?.autoJoinDelay || 5000;
    const maxTargets = globalSettings?.maxTargetsPerUserbot || 500;

    // Only scan if we haven't scanned recently (10 min cooldown)
    const lastScan = userbot.autoPilot?.lastScanAt || 0;
    if (Date.now() - lastScan < 10 * 60 * 1000) {
      return 0;
    }

    let joinedCount = 0;
    const existingChatIds = new Set(userbot.settings.targets.map(t => t.chatId));
    const foundLinks: { type: 'username' | 'invite', value: string }[] = [];

    // Scan messages from targets
    for (const target of userbot.settings.targets.slice(0, 30)) {
      try {
        const entity = await client.client.getEntity(target.chatId);
        const messages = await client.client.getMessages(entity, { limit: 100 });

        for (const msg of messages) {
          if (!msg.message) continue;
          const links = this.extractLinksFromText(msg.message);
          foundLinks.push(...links);
          
          // Also check message entities for links
          if (msg.entities) {
            for (const ent of msg.entities) {
              // @ts-ignore
              if (ent.className === 'MessageEntityMention' || ent.className === 'MessageEntityTextUrl') {
                // @ts-ignore
                const url = ent.url || msg.message.substring(ent.offset, ent.offset + ent.length);
                if (url) {
                  const entityLinks = this.extractLinksFromText(url);
                  foundLinks.push(...entityLinks);
                }
              }
            }
          }
        }
      } catch (e: any) {
        logger.debug(`Failed to scan ${target.chatId}: ${e?.message}`);
      }
    }

    // Deduplicate
    const uniqueLinks = new Map<string, { type: 'username' | 'invite', value: string }>();
    for (const link of foundLinks) {
      uniqueLinks.set(link.value.toLowerCase(), link);
    }

    // Join found groups
    let processedCount = 0;
    for (const link of Array.from(uniqueLinks.values())) {
      if (userbot.settings.targets.length >= maxTargets) {
        logger.info(`Max targets reached for ${userbot.label}`);
        break;
      }

      // Cooldown every 5 joins
      if (processedCount > 0 && processedCount % 5 === 0) {
        logger.info(`AutoPilot cooldown: Waiting 5 minutes...`);
        await sleep(5 * 60 * 1000);
      }

      try {
        let entity: any;
        let chatId: string = '';
        let title: string = '';

        if (link.type === 'invite') {
          // Invite link
          const hash = link.value.replace(/^\+/, '');
          try {
            const result = await client.client.invoke(new Api.messages.ImportChatInvite({ hash }));
            // @ts-ignore
            entity = result.chats?.[0];
            chatId = entity?.id?.toString() || '';
            title = entity?.title || 'Joined Group';
          } catch (e: any) {
            if (e.message?.includes('USER_ALREADY_PARTICIPANT')) {
              // Get info about the chat we're already in
              try {
                const info = await client.client.invoke(new Api.messages.CheckChatInvite({ hash }));
                // @ts-ignore
                entity = info.chat || info;
                // @ts-ignore
                chatId = entity?.id?.toString() || '';
                // @ts-ignore
                title = entity?.title || 'Existing Group';
              } catch {
                continue;
              }
            } else {
              throw e;
            }
          }
        } else {
          // Username
          try {
            entity = await client.client.getEntity('@' + link.value);
          } catch {
            entity = await client.client.getEntity(link.value);
          }
          
          chatId = entity.id?.toString() || '';
          title = entity.title || link.value;

          if (existingChatIds.has(chatId)) continue;

          // Check if it's a group/channel
          const className = entity.className || '';
          if (!className.includes('Channel') && !className.includes('Chat')) {
            continue;
          }

          // Try to join if not already member
          try {
            await client.client.invoke(new Api.channels.JoinChannel({ channel: entity }));
          } catch (e: any) {
            if (!e.message?.includes('USER_ALREADY_PARTICIPANT')) {
              throw e;
            }
          }
        }

        if (chatId && !existingChatIds.has(chatId)) {
          await jsonDb.updateUserbot(userbotId, u => {
            u.settings.targets.push({
              chatId,
              title,
              username: link.value,
              addedAt: Date.now()
            });
            return u;
          });
          existingChatIds.add(chatId);
          joinedCount++;
          processedCount++;
          logger.info(`AutoPilot: Joined ${title} (${chatId})`);
        }

        await sleep(joinDelay);

      } catch (e: any) {
        if (e.message?.includes('FLOOD_WAIT')) {
          const waitTime = e.seconds || parseInt(e.message.match(/\d+/)?.[0] || '60');
          logger.warn(`FloodWait on join: Waiting ${waitTime}s`);
          await sleep(waitTime * 1000);
        } else if (e.message?.includes('CHANNELS_TOO_MUCH')) {
          logger.warn(`Account has joined too many channels`);
          break;
        } else {
          logger.debug(`Failed to join ${link.value}: ${e?.message}`);
        }
      }
    }

    // Update last scan time
    await jsonDb.updateUserbot(userbotId, u => {
      if (!u.autoPilot) {
        u.autoPilot = { enabled: true, scanLinks: true, autoJoin: true, joinedCount: 0, lastScanAt: 0 };
      }
      u.autoPilot.lastScanAt = Date.now();
      u.autoPilot.joinedCount = (u.autoPilot.joinedCount || 0) + joinedCount;
      return u;
    });

    return joinedCount;
  }

  async scanChannelForLinks(userbotId: string, channelUsername: string): Promise<number> {
    const client = userbotManager.getClient(userbotId);
    if (!client) throw new Error('Userbot not connected');

    const db = await jsonDb.read();
    const userbot = db.userbots.find(u => u.id === userbotId);
    if (!userbot) throw new Error('Userbot not found');

    const globalSettings = db.globalSettings;
    const joinDelay = globalSettings?.autoJoinDelay || 5000;

    try {
      // Resolve channel
      let channel: any;
      try {
        channel = await client.client.getEntity(channelUsername);
      } catch {
        channel = await client.client.getEntity('@' + channelUsername.replace('@', ''));
      }
      
      const messages = await client.client.getMessages(channel, { limit: 300 });
      
      const allLinks: { type: 'username' | 'invite', value: string }[] = [];
      
      for (const msg of messages) {
        if (!msg.message) continue;
        allLinks.push(...this.extractLinksFromText(msg.message));
        
        // Check entities
        if (msg.entities) {
          for (const ent of msg.entities) {
            // @ts-ignore
            if (ent.url) {
              // @ts-ignore
              allLinks.push(...this.extractLinksFromText(ent.url));
            }
          }
        }
      }

      // Deduplicate
      const uniqueLinks = new Map<string, { type: 'username' | 'invite', value: string }>();
      for (const link of allLinks) {
        uniqueLinks.set(link.value.toLowerCase(), link);
      }
      
      logger.info(`Found ${uniqueLinks.size} unique links in ${channelUsername}`);

      let joinedCount = 0;
      let processedCount = 0;
      const existingChatIds = new Set(userbot.settings.targets.map(t => t.chatId));

      for (const link of Array.from(uniqueLinks.values())) {
        if (processedCount > 0 && processedCount % 5 === 0) {
          logger.info(`Cooldown: Waiting 5 minutes after ${processedCount} joins...`);
          await sleep(5 * 60 * 1000);
        }

        try {
          let entity: any;
          let chatId: string = '';
          let title: string = '';

          if (link.type === 'invite') {
            const hash = link.value.replace(/^\+/, '');
            try {
              const result = await client.client.invoke(new Api.messages.ImportChatInvite({ hash }));
              // @ts-ignore
              entity = result.chats?.[0];
              chatId = entity?.id?.toString() || '';
              title = entity?.title || 'Joined Group';
            } catch (e: any) {
              if (e.message?.includes('USER_ALREADY_PARTICIPANT')) {
                try {
                  const info = await client.client.invoke(new Api.messages.CheckChatInvite({ hash }));
                  // @ts-ignore
                  entity = info.chat || info;
                  // @ts-ignore
                  chatId = entity?.id?.toString() || '';
                  // @ts-ignore
                  title = entity?.title || 'Existing Group';
                } catch {
                  continue;
                }
              } else {
                throw e;
              }
            }
          } else {
            try {
              entity = await client.client.getEntity('@' + link.value);
            } catch {
              entity = await client.client.getEntity(link.value);
            }
            
            chatId = entity.id?.toString() || '';
            title = entity.title || link.value;

            if (existingChatIds.has(chatId)) continue;
            
            const className = entity.className || '';
            if (!className.includes('Channel') && !className.includes('Chat')) continue;
            
            try {
              await client.client.invoke(new Api.channels.JoinChannel({ channel: entity }));
            } catch (e: any) {
              if (!e.message?.includes('USER_ALREADY_PARTICIPANT')) throw e;
            }
          }

          if (chatId && !existingChatIds.has(chatId)) {
            await jsonDb.updateUserbot(userbotId, u => {
              u.settings.targets.push({
                chatId,
                title,
                username: link.value,
                addedAt: Date.now()
              });
              return u;
            });
            existingChatIds.add(chatId);
            joinedCount++;
            processedCount++;
            logger.info(`Joined: ${title} (${chatId})`);
          }

          await sleep(joinDelay);

        } catch (e: any) {
          if (e.message?.includes('FLOOD_WAIT')) {
            const waitTime = e.seconds || parseInt(e.message.match(/\d+/)?.[0] || '60');
            logger.warn(`FloodWait: Waiting ${waitTime}s`);
            await sleep(waitTime * 1000);
          }
        }
      }

      return joinedCount;
    } catch (e: any) {
      throw new Error(`Channel scan failed: ${e?.message}`);
    }
  }
}

export const linkScanner = new LinkScanner();
