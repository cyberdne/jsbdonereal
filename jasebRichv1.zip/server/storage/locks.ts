import { Mutex } from 'async-mutex';

export const locks = {
  db: new Mutex(),
  userbot: (id: string) => new Mutex(), // Dynamic lock handling would be better, but for now simple mutex
};

const userbotLocks = new Map<string, Mutex>();
export function getUserbotLock(id: string): Mutex {
  if (!userbotLocks.has(id)) {
    userbotLocks.set(id, new Mutex());
  }
  return userbotLocks.get(id)!;
}
