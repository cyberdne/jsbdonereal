import type { Express } from "express";
import { createServer, type Server } from "http";
import { api } from "@shared/routes";
import { jsonDb } from "./storage/db";
import { jasebBot } from "./bot/bot";
import { userbotManager } from "./userbots/userbot.manager";
import { jobRunner } from "./jaseb/job.runner";
import { timerScheduler } from "./scheduler/timer.scheduler";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // API Stats Endpoint
  app.get(api.stats.get.path, async (req, res) => {
    try {
      const db = await jsonDb.read();
      const status = {
        status: 'online',
        userbots_count: db.userbots.length,
        active_jobs: Object.keys(db.jobs).filter(k => db.jobs[k].running).length, // simplified
        total_sent: db.userbots.reduce((acc, u) => acc + u.stats.sent, 0),
        uptime: process.uptime()
      };
      res.json(status);
    } catch (e) {
      res.status(500).json({ error: 'Failed to fetch stats' });
    }
  });

  // Start the Bot
  try {
    console.log('Starting JASEB Bot...');
    await jasebBot.launch();
    
    // Start Scheduler
    timerScheduler.start();
    
    console.log('JASEB Bot started successfully.');
  } catch (e) {
    console.error('Failed to start JASEB Bot:', e);
  }

  return httpServer;
}
