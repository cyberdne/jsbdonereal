import { Api } from 'telegram';
import { userbotManager } from '../userbots/userbot.manager';
import { jsonDb } from '../storage/db';
import { linkScanner } from './link.scanner';
import { liveEvents } from '../utils/live-events';
import pino from 'pino';

const logger = pino({ level: 'info' });

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

export class JobRunner {
  private activeJobs = new Map<string, boolean>();
  private jobQueues = new Map<string, Promise<void>>();

  async startJob(userbotId: string) {
    if (this.activeJobs.get(userbotId)) return;
    this.activeJobs.set(userbotId, true);
    
    const jobPromise = this.runLoop(userbotId).catch(e => {
      logger.error(`Job ${userbotId} crashed: ${e?.message}`);
      this.activeJobs.delete(userbotId);
      jsonDb.updateUserbot(userbotId, u => { 
        u.status = 'ERROR'; 
        u.stats.lastError = e?.message || 'Unknown error';
        return u; 
      });
    });
    
    this.jobQueues.set(userbotId, jobPromise);
  }

  async stopJob(userbotId: string) {
    this.activeJobs.set(userbotId, false);
    this.activeJobs.delete(userbotId);
  }

  isRunning(userbotId: string) {
    return this.activeJobs.get(userbotId) === true;
  }

  private async runLoop(userbotId: string) {
    logger.info(`Starting job loop for ${userbotId}`);
    
    while (this.activeJobs.get(userbotId)) {
      const db = await jsonDb.read();
      const userbot = db.userbots.find(u => u.id === userbotId);
      const globalSettings = db.globalSettings;
       
      if (!userbot) {
        this.activeJobs.delete(userbotId);
        break;
      }

      // Check subscription
      if (!userbot.subscription.active || userbot.subscription.expireAt < Date.now()) {
        logger.info(`Subscription expired for ${userbot.label}, stopping job`);
        await jsonDb.updateUserbot(userbotId, u => {
          u.status = 'OFF_SUBS';
          u.subscription.autoOffApplied = true;
          return u;
        });
        this.activeJobs.delete(userbotId);
        break;
      }

      if (userbot.status !== 'RUNNING') {
        this.activeJobs.delete(userbotId);
        break;
      }

      const gramClient = userbotManager.getClient(userbotId);
      if (!gramClient) {
        logger.warn(`Client not found for ${userbotId}, attempting reconnect...`);
        try {
          await userbotManager.startClient(userbotId);
          await sleep(2000);
        } catch (e: any) {
          logger.error(`Failed to reconnect ${userbotId}: ${e?.message}`);
          this.activeJobs.delete(userbotId);
          await jsonDb.updateUserbot(userbotId, u => { u.status = 'ERROR'; return u; });
          break;
        }
        continue;
      }

      // Auto Pilot - Scan links from targets if enabled
      if (userbot.autoPilot?.enabled && userbot.autoPilot?.scanLinks) {
        try {
          const newCount = await linkScanner.scanAndJoinFromTargets(userbotId);
          if (newCount > 0) {
            logger.info(`AutoPilot: Joined ${newCount} new groups for ${userbot.label}`);
          }
        } catch (e: any) {
          logger.error(`AutoPilot scan error: ${e?.message}`);
        }
      }

      // --- BROADCAST LOGIC ---
      const targets = userbot.settings.targets;
      const blacklist = [...(userbot.settings.blacklist || []), ...(globalSettings?.globalBlacklist || [])];
      
      // Get delay settings - respect user configuration exactly
      const instantLoopDelaySec = Math.max(userbot.settings.delays.instantLoopDelaySec || 60, 60);
      const sequentialDelayPerGroupSec = Math.max(userbot.settings.delays.sequentialPerGroupDelaySec || 5, 1); // Allow lower for instant mode
      const isInstantMode = userbot.settings.spreadMode === 'INSTANT';
      
      // Emit initial broadcast progress
      const startTime = Date.now();
      liveEvents.emitBroadcastProgress({
        userbotId,
        totalTargets: targets.length,
        currentIndex: 0,
        sent: 0,
        failed: 0,
        skipped: 0,
        percentComplete: 0,
        status: 'running',
        startedAt: startTime,
      });
      
      // Smart target filtering - skip banned/forbidden targets from previous rounds
      const activableTargets = targets.filter((t: any) => {
        const isBanned = t.banStatus === 'BANNED' || t.banStatus === 'FORBIDDEN';
        const isBlacklisted = blacklist.includes(t.chatId);
        return !isBlacklisted && !isBanned;
      });
      
      logger.info(`${userbot.label}: Processing ${activableTargets.length}/${targets.length} targets (${targets.length - activableTargets.length} skipped)`);
      
      let sentCount = 0;
      let failedCount = 0;
      let skippedCount = targets.length - activableTargets.length; // Count pre-skipped from previous rounds
      let processedCount = 0;
      
        // INSTANT mode: Process in batches in parallel
        // SEQUENTIAL mode: Process one by one with delays
      
        if (isInstantMode) {
          // ===== INSTANT MODE: Batch parallel processing =====
          const batchSize = 10; // Process 10 targets in parallel per batch
        
          for (let batchIndex = 0; batchIndex < activableTargets.length; batchIndex += batchSize) {
            if (!this.activeJobs.get(userbotId)) break;
          
            const batchTargets = activableTargets.slice(batchIndex, batchIndex + batchSize);
            processedCount += batchTargets.length;
          
            // Emit progress before batch
            liveEvents.emitBroadcastProgress({
              userbotId,
              totalTargets: activableTargets.length,
              currentIndex: processedCount,
              sent: sentCount,
              failed: failedCount,
              skipped: skippedCount,
              currentTarget: batchTargets.length > 0 ? batchTargets[0].username || batchTargets[0].chatId : undefined,
              percentComplete: Math.round((processedCount / activableTargets.length) * 100),
              status: 'running',
              startedAt: startTime,
              estimatedTimeLeft: this.estimateTimeLeft(sentCount, activableTargets.length - processedCount, startTime, isInstantMode),
            });
          
            // Process entire batch in parallel (instant sending)
            const batchPromises = batchTargets.map(async (target) => {
              try {
                if (blacklist.includes(target.chatId)) {
                  skippedCount++;
                  return { success: false, error: 'blacklisted' };
                }
              
                let entity: any;
                try {
                  entity = await gramClient.client.getEntity(target.chatId);
                } catch {
                  if (target.username) {
                    entity = await gramClient.client.getEntity(target.username);
                  } else {
                    throw new Error('Cannot resolve entity');
                  }
                }
              
                // Send message
                if (userbot.settings.messageType === 'FORWARD' && userbot.settings.forwardedMessage) {
                  await this.sendForwardMessage(gramClient, userbot, entity);
                } else if (userbot.settings.messageType === 'FORWARD' && userbot.settings.forwardConfig?.chatId) {
                  await this.sendForwardFromConfig(gramClient, userbot, entity);
                } else {
                  await this.sendRegularMessage(gramClient, userbot, entity, globalSettings);
                }

                sentCount++;
              
                await jsonDb.updateUserbot(userbotId, u => {
                  u.stats.sent += 1;
                  u.stats.lastRunAt = Date.now();
                  const t = u.settings.targets.find(x => x.chatId === target.chatId);
                  if (t) {
                    t.lastSentAt = Date.now();
                    t.banStatus = 'ACTIVE';
                    t.retryCount = 0;
                  }
                  return u;
                });
              
                return { success: true };
              
              } catch (e: any) {
                const errorResult = await this.handleSendError(e, userbotId, target.chatId);
              
                if (errorResult.shouldSkip) {
                  skippedCount++;
                } else if (errorResult.shouldWait) {
                  logger.warn(`${userbot.label}: FloodWait ${errorResult.waitTime}s, pausing batch...`);
                  await sleep(errorResult.waitTime * 1000);
                } else {
                  failedCount++;
                }
              
                return { success: false, error: errorResult.reason };
              }
            });
          
            // Wait for entire batch to complete
            await Promise.allSettled(batchPromises);
          
            // Delay between batches (user's per-group delay, applied after batch)
            if (batchIndex + batchSize < activableTargets.length) {
              const delayMs = sequentialDelayPerGroupSec * 1000;
              if (delayMs > 0) {
                logger.info(`${userbot.label}: Batch ${Math.ceil((batchIndex + 1) / batchSize)} done, waiting ${sequentialDelayPerGroupSec}s before next batch...`);
                await sleep(delayMs);
              }
            }
          }
        
        } else {
          // ===== SEQUENTIAL MODE: One by one with full delay =====
          for (const target of activableTargets) {
            if (!this.activeJobs.get(userbotId)) break;
          
            processedCount++;
          
            // Emit progress before processing
        liveEvents.emitBroadcastProgress({
          userbotId,
            totalTargets: activableTargets.length,
          currentIndex: processedCount,
          sent: sentCount,
          failed: failedCount,
          skipped: skippedCount,
            currentTarget: target.username || target.chatId,
            percentComplete: Math.round((processedCount / activableTargets.length) * 100),
          status: 'running',
          startedAt: startTime,
          estimatedTimeLeft: this.estimateTimeLeft(sentCount, activableTargets.length - processedCount, startTime, isInstantMode),
        });
        
            // Apply full delay BEFORE sending (sequential mode)
            if (processedCount > 0) {
              const seqDelayMs = sequentialDelayPerGroupSec * 1000;
              if (seqDelayMs > 0) {
                await sleep(seqDelayMs);
              }
            }
          
            try {
          if (blacklist.includes(target.chatId)) {
            skippedCount++;
            continue;
          }
          
          let entity: any;
          try {
            entity = await gramClient.client.getEntity(target.chatId);
          } catch {
            if (target.username) {
              entity = await gramClient.client.getEntity(target.username);
            } else {
              throw new Error('Cannot resolve entity');
            }
          }
          
            // Send message
          if (userbot.settings.messageType === 'FORWARD' && userbot.settings.forwardedMessage) {
            await this.sendForwardMessage(gramClient, userbot, entity);
          } else if (userbot.settings.messageType === 'FORWARD' && userbot.settings.forwardConfig?.chatId) {
            await this.sendForwardFromConfig(gramClient, userbot, entity);
          } else {
            await this.sendRegularMessage(gramClient, userbot, entity, globalSettings);
          }

          sentCount++;

          await jsonDb.updateUserbot(userbotId, u => {
            u.stats.sent += 1;
            u.stats.lastRunAt = Date.now();
            const t = u.settings.targets.find(x => x.chatId === target.chatId);
            if (t) {
              t.lastSentAt = Date.now();
                t.banStatus = 'ACTIVE';
              t.retryCount = 0;
            }
            return u;
          });

            } catch (e: any) {
              const errorResult = await this.handleSendError(e, userbotId, target.chatId);
            
              if (errorResult.shouldSkip) {
                skippedCount++;
                logger.info(`${userbot.label}: Skipping ${target.username || target.chatId} (${errorResult.reason}). Will retry next round.`);
              } else if (errorResult.shouldWait) {
                logger.warn(`${userbot.label}: FloodWait detected. Waiting ${errorResult.waitTime}s then continuing...`);
                await sleep(errorResult.waitTime * 1000);
              } else {
                failedCount++;
              }
            }
          }
        }

      // Final progress update
      const totalProcessed = sentCount + failedCount + skippedCount;
      liveEvents.emitBroadcastProgress({
        userbotId,
        totalTargets: targets.length,
        currentIndex: totalProcessed,
        sent: sentCount,
        failed: failedCount,
        skipped: skippedCount,
        percentComplete: 100,
        status: 'completed',
        startedAt: startTime,
        estimatedTimeLeft: 0,
      });

      logger.info(`${userbot.label}: Broadcast completed - Sent: ${sentCount}, Failed: ${failedCount}, Skipped: ${skippedCount}`);

      // Loop delay - respect user configuration
      const loopDelayMs = isInstantMode ? instantLoopDelaySec * 1000 : 10000;
      logger.info(`${userbot.label}: Waiting ${loopDelayMs / 1000}s before next round...`);
      await sleep(loopDelayMs);
    }
    
    logger.info(`Job loop for ${userbotId} stopped`);
  }

  private estimateTimeLeft(sentCount: number, remainingTargets: number, startTime: number, isInstantMode: boolean): number {
    if (sentCount === 0) return remainingTargets * 5000; // Default estimate
    const elapsedMs = Date.now() - startTime;
    const msPerMessage = elapsedMs / sentCount;
    return remainingTargets * msPerMessage;
  }

  private async sendForwardMessage(client: any, userbot: any, targetEntity: any) {
    const fwdMsg = userbot.settings.forwardedMessage;
    
    if (fwdMsg?.chatId && fwdMsg?.messageIds?.length > 0) {
      try {
        const fromEntity = await client.client.getEntity(fwdMsg.chatId);
        await client.client.forwardMessages(targetEntity, {
          messages: fwdMsg.messageIds,
          fromPeer: fromEntity
        });
        return;
      } catch (e: any) {
        logger.error(`Forward error: ${e?.message}`);
        throw e;
      }
    }
    
    throw new Error('No forwarded message configured');
  }

  private async sendForwardFromConfig(client: any, userbot: any, targetEntity: any) {
    const config = userbot.settings.forwardConfig;
    
    if (config?.chatId && config?.messageIds?.length > 0) {
      try {
        const fromEntity = await client.client.getEntity(config.chatId);
        await client.client.forwardMessages(targetEntity, {
          messages: config.messageIds,
          fromPeer: fromEntity
        });
        return;
      } catch (e: any) {
        logger.error(`Forward config error: ${e?.message}`);
        throw e;
      }
    }
    
    throw new Error('No forward config');
  }

  private async sendRegularMessage(client: any, userbot: any, targetEntity: any, globalSettings: any) {
    let text = userbot.settings.regularText || '';
    
    if (!text) {
      throw new Error('No regular text configured');
    }
    
    const watermark = userbot.settings.watermarkText || globalSettings?.defaultWatermark;
    const message = this.buildMessage(text, watermark);
    
    if (userbot.settings.premiumEmoji || globalSettings?.defaultPremiumEmoji) {
      await client.client.sendMessage(targetEntity, { 
        message,
        parseMode: 'html'
      });
    } else {
      await client.client.sendMessage(targetEntity, { message });
    }
  }

  private async handleSendError(e: any, userbotId: string, targetChatId: string): Promise<{ shouldSkip: boolean; shouldWait: boolean; waitTime: number; reason: string }> {
    logger.error(`Failed to send to ${targetChatId}: ${e?.message}`);
    
    // ===== FLOOD_WAIT HANDLING - Smart non-blocking wait =====
    if (e.message?.includes('FLOOD_WAIT') || e.seconds) {
      const waitTime = e.seconds || parseInt(e.message.match(/\d+/)?.[0] || '60');
      logger.warn(`FloodWait: ${waitTime}s detected. Marking target for skip and continuing...`);
      
      // Mark target as banned so it's skipped in next round, don't block current round
      await jsonDb.updateUserbot(userbotId, u => {
        const t = u.settings.targets.find(x => x.chatId === targetChatId);
        if (t) {
          t.banStatus = 'BANNED';
          t.lastBanAt = Date.now();
          t.banReason = `FLOOD_WAIT: ${waitTime}s`;
          t.retryCount = (t.retryCount || 0) + 1;
        }
        return u;
      });
      
      // Return to skip this target and continue with others
      return { shouldSkip: true, shouldWait: true, waitTime, reason: 'FLOOD_WAIT' };
    }
    
    // ===== BAN/FORBIDDEN HANDLING - Mark for skip in next round =====
    if (e.message?.includes('CHAT_WRITE_FORBIDDEN') || 
        e.message?.includes('USER_BANNED_IN_CHANNEL') ||
        e.message?.includes('CHANNEL_PRIVATE') ||
        e.message?.includes('USER_RESTRICTED') ||
        e.message?.includes('PARTICIPANT_VERSION_OUTDATED')) {
      
      const banReason = e.message?.substring(0, 50) || 'UNKNOWN_BAN';
      logger.warn(`Ban/Forbidden detected for ${targetChatId}: ${banReason}. Marking for skip.`);
      
      // Mark as FORBIDDEN and skip
      await jsonDb.updateUserbot(userbotId, u => {
        u.stats.skipped += 1;
        const t = u.settings.targets.find(x => x.chatId === targetChatId);
        if (t) {
          t.banStatus = 'FORBIDDEN';
          t.lastBanAt = Date.now();
          t.banReason = banReason;
          t.failCount = (t.failCount || 0) + 1;
          t.retryCount = (t.retryCount || 0) + 1;
        }
        return u;
      });
      
      return { shouldSkip: true, shouldWait: false, waitTime: 0, reason: banReason };
    }
    
    // ===== OTHER ERRORS - Increment fail count =====
    await jsonDb.updateUserbot(userbotId, u => {
      u.stats.failed += 1;
      u.stats.lastError = e?.message?.substring(0, 100);
      return u;
    });
    
    return { shouldSkip: false, shouldWait: false, waitTime: 0, reason: 'SEND_ERROR' };
  }

  private buildMessage(text: string, watermark?: string): string {
    if (!watermark) return text;
    return `${text}\n\n${watermark}`;
  }
}

export const jobRunner = new JobRunner();
