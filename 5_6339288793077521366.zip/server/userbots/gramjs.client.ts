import { TelegramClient } from 'telegram';
import { StringSession } from 'telegram/sessions';
import { ENV } from '../config/env';
import pino from 'pino';

const logger = pino({ level: ENV.LOG_LEVEL });

export class GramJsClient {
  public client: TelegramClient;
  public session: StringSession;
  public phoneNumber?: string;

  constructor(sessionString: string = '', phoneNumber?: string) {
    this.session = new StringSession(sessionString);
    this.phoneNumber = phoneNumber;
    this.client = new TelegramClient(this.session, ENV.API_ID, ENV.API_HASH, {
      connectionRetries: 5,
    });
  }

  async connect() {
    await this.client.connect();
  }

  async disconnect() {
    try {
      await this.client.disconnect();
    } catch (e) {
      // Ignore disconnect errors
    }
  }

  async getMe() {
    return await this.client.getMe();
  }

  getSessionString() {
    return this.session.save();
  }

  async sendCode(phone: string) {
    return await this.client.sendCode(
      { apiId: ENV.API_ID, apiHash: ENV.API_HASH },
      phone
    );
  }

  async ping() {
    const start = Date.now();
    await this.client.getMe();
    return Date.now() - start;
  }
}
