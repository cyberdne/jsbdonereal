import { userbotManager } from '../userbots/userbot.manager';
import { jsonDb } from '../storage/db';
import pino from 'pino';

const logger = pino({ level: 'info' });

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

export class BroadcastPrivateMessagesService {
  /**
   * Broadcast pesan ke semua user yang pernah interaksi dengan userbot
   * Implementasi dasar: mengirim ke semua `settings.targets` yang tercatat
   */
  async broadcastToPrivateChats(userbotId: string, message?: string): Promise<{ sent: number; failed: number }> {
    const client = userbotManager.getClient(userbotId);
    if (!client) throw new Error('Client not connected');

    let sent = 0;
    let failed = 0;

    try {
      logger.info(`Broadcasting message to private chats for ${userbotId}`);

      const db = await jsonDb.read();
      const userbot = db.userbots.find(u => u.id === userbotId);
      if (!userbot) throw new Error('Userbot not found');

      const bcSettings: any = userbot.settings.broadcastPrivateMessages || {};
      const text = message || bcSettings.message || userbot.settings.regularText || '';

      if (!text) throw new Error('No message provided for broadcast');

      const delivery = userbot.settings.messageDelivery || { showTypingIndicator: false, typingDelayMs: 1000 };

      const targets = userbot.settings.targets || [];

      for (const t of targets) {
        try {
          // Resolve entity (chatId or username)
          let entity: any;
          try {
            entity = await client.client.getEntity(t.chatId);
          } catch (err) {
            if (t.username) entity = await client.client.getEntity(t.username);
            else throw err;
          }

          if (delivery.showTypingIndicator) {
            const delay = delivery.typingDelayMs || 1000;
            await sleep(delay + Math.floor(Math.random() * 500));
          }

          await client.client.sendMessage(entity, { message: text, parseMode: 'html' });
          sent += 1;

          // gentle pacing
          await sleep(400 + Math.floor(Math.random() * 600));
        } catch (e: any) {
          failed += 1;
          const em = (e as any)?.message;
          logger.warn(`Broadcast send failed for target ${t.chatId}: ${em}`);

          // Handle flood wait conservatively
          if ((e as any)?.seconds || /FLOOD_WAIT/.test(em || '')) {
            const waitSec = (e as any)?.seconds || parseInt((em || '').match(/\d+/)?.[0] || '60');
            logger.warn(`Flood wait detected: sleeping ${waitSec}s`);
            await sleep(waitSec * 1000);
          }

          // update per-target failures/stats
          await jsonDb.updateUserbot(userbotId, u => {
            u.stats.failed = (u.stats.failed || 0) + 1;
            return u;
          });
        }
      }

      // persist broadcast stats
      await jsonDb.updateUserbot(userbotId, u => {
        if (!u.settings.broadcastPrivateMessages) {
          u.settings.broadcastPrivateMessages = { enabled: false, message: text, targetCount: 0 } as any;
        }
        u.settings.broadcastPrivateMessages!.lastExecutedAt = Date.now();
        u.settings.broadcastPrivateMessages!.targetCount = sent;
        u.stats.lastRunAt = Date.now();
        return u;
      });

      logger.info(`Broadcast completed: ${sent} sent, ${failed} failed`);
      return { sent, failed };
    } catch (e: any) {
      logger.error(`Broadcast error: ${e?.message}`);
      throw e;
    }
  }
}

export const broadcastPrivateMessagesService = new BroadcastPrivateMessagesService();

