import { DateTime } from 'luxon';

/**
 * Mendapatkan waktu saat ini berdasarkan timezone yang diset
 * @param timezone Timezone string (e.g., 'Asia/Jakarta', 'UTC')
 * @returns Waktu saat ini di timezone tersebut dalam format HH:mm
 */
export function getCurrentTimeInTimezone(timezone: string = "Asia/Jakarta"): string {
  const now = DateTime.now().setZone(timezone);
  return now.toFormat('HH:mm');
}

/**
 * Mendapatkan waktu saat ini berdasarkan timezone yang diset (dengan detil)
 */
export function getCurrentTimeDetailInTimezone(timezone: string = "Asia/Jakarta") {
  return DateTime.now().setZone(timezone);
}

/**
 * Parse waktu string (HH:mm) dengan timezone tertentu
 */
export function parseTimeInTimezone(timeStr: string, timezone: string = "Asia/Jakarta") {
  const [hours, minutes] = timeStr.split(':').map(Number);
  const now = DateTime.now().setZone(timezone);
  return now.set({ hour: hours, minute: minutes });
}

/**
 * Cek apakah waktu sekarang sama dengan waktu yang diberikan
 */
export function isCurrentTime(targetTime: string, timezone: string = "Asia/Jakarta"): boolean {
  const current = getCurrentTimeInTimezone(timezone);
  return current === targetTime;
}

/**
 * Validasi format HH:mm
 */
export function isValidTimeFormat(timeStr: string): boolean {
  const regex = /^([0-1][0-9]|2[0-3]):[0-5][0-9]$/;
  return regex.test(timeStr);
}
