/**
 * Live Events System - Real-time data updates untuk user interface
 * Meng-emit events untuk progress broadcast, stats update, dan status changes
 */

import { EventEmitter } from 'events';
import pino from 'pino';

const logger = pino({ level: 'info' });

export interface BroadcastProgressEvent {
  userbotId: string;
  totalTargets: number;
  currentIndex: number;
  sent: number;
  failed: number;
  skipped: number;
  currentTarget?: string;
  percentComplete: number;
  status: 'running' | 'completed' | 'failed' | 'paused';
  startedAt: number;
  estimatedTimeLeft?: number;
}

export interface UserbotupdateEvent {
  userbotId: string;
  label: string;
  status: string;
  stats: {
    sent: number;
    failed: number;
    skipped: number;
  };
  updatedAt: number;
}

export interface GlobalStatsEvent {
  totalUserbots: number;
  activeUserbots: number;
  totalSent: number;
  totalFailed: number;
  totalTargets: number;
  updatedAt: number;
}

class LiveEventsManager extends EventEmitter {
  private broadcastProgress = new Map<string, BroadcastProgressEvent>();
  private userbotupdates = new Map<string, UserbotupdateEvent>();

  constructor() {
    super();
    this.setMaxListeners(100);
  }

  /**
   * Emit broadcast progress event
   */
  emitBroadcastProgress(event: BroadcastProgressEvent) {
    this.broadcastProgress.set(event.userbotId, event);
    this.emit('broadcast:progress', event);
    logger.debug(`Broadcast progress: ${event.userbotId} - ${event.percentComplete}%`);
  }

  /**
   * Emit userbot stats update
   */
  emitUserbotupdateEvent(event: UserbotupdateEvent) {
    this.userbotupdates.set(event.userbotId, event);
    this.emit('userbot:update', event);
    logger.debug(`Userbot update: ${event.label} - ${event.status}`);
  }

  /**
   * Emit global stats update
   */
  emitGlobalStats(event: GlobalStatsEvent) {
    this.emit('stats:global', event);
    logger.debug(`Global stats update at ${new Date(event.updatedAt).toLocaleTimeString()}`);
  }

  /**
   * Get current broadcast progress untuk specific userbot
   */
  getBroadcastProgress(userbotId: string): BroadcastProgressEvent | undefined {
    return this.broadcastProgress.get(userbotId);
  }

  /**
   * Get current userbot update untuk specific userbot
   */
  getUserbotupdateEvent(userbotId: string): UserbotupdateEvent | undefined {
    return this.userbotupdates.get(userbotId);
  }

  /**
   * Get all active broadcasts
   */
  getAllBroadcasts(): BroadcastProgressEvent[] {
    return Array.from(this.broadcastProgress.values());
  }

  /**
   * Clear broadcast progress untuk specific userbot (ketika complete)
   */
  clearBroadcastProgress(userbotId: string) {
    this.broadcastProgress.delete(userbotId);
  }

  /**
   * Subscribe ke broadcast progress updates
   */
  onBroadcastProgress(callback: (event: BroadcastProgressEvent) => void) {
    this.on('broadcast:progress', callback);
    return () => this.removeListener('broadcast:progress', callback);
  }

  /**
   * Subscribe ke userbot updates
   */
  onUserbotupdateEvent(callback: (event: UserbotupdateEvent) => void) {
    this.on('userbot:update', callback);
    return () => this.removeListener('userbot:update', callback);
  }

  /**
   * Subscribe ke global stats
   */
  onGlobalStats(callback: (event: GlobalStatsEvent) => void) {
    this.on('stats:global', callback);
    return () => this.removeListener('stats:global', callback);
  }
}

export const liveEvents = new LiveEventsManager();
