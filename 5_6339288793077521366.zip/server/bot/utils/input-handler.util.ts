/**
 * Input handler helper functions untuk input.router.ts
 * Mengurangi duplikasi code dan meningkatkan maintainability
 */

import type { Context } from 'telegraf';
import { Validators, BotError, ICONS, Format } from './error.util';
import { jsonDb } from '../../storage/db';
import pino from 'pino';

const logger = pino({ level: 'info' });

/**
 * Validate delay input (dalam seconds)
 * @param input User input
 * @param minSeconds Minimum detik
 * @param maxSeconds Maximum detik
 * @returns {valid, value, error}
 */
export function validateDelay(
  input: string,
  minSeconds: number = 1,
  maxSeconds: number = 3600
): { valid: boolean; value?: number; error?: string } {
  const num = parseInt(input.trim());
  
  if (isNaN(num)) {
    return { valid: false, error: `Harus berupa angka` };
  }
  
  if (num < minSeconds) {
    return { valid: false, error: `Minimum ${minSeconds} detik` };
  }
  
  if (num > maxSeconds) {
    return { valid: false, error: `Maximum ${maxSeconds} detik` };
  }
  
  return { valid: true, value: num };
}

/**
 * Validate time format dan convert ke HH:MM
 */
export function validateTimeFormat(
  input: string
): { valid: boolean; value?: string; error?: string } {
  const trimmed = input.trim();
  
  if (!Validators.timeFormat(trimmed)) {
    return { valid: false, error: `Format harus HH:MM (contoh: 08:00)` };
  }
  
  return { valid: true, value: trimmed };
}

/**
 * Validate timezone
 */
export function validateTimezone(
  input: string
): { valid: boolean; value?: string; error?: string } {
  const trimmed = input.trim();
  
  if (!Validators.timezone(trimmed)) {
    return { valid: false, error: `Timezone tidak valid. Contoh: Asia/Jakarta` };
  }
  
  return { valid: true, value: trimmed };
}

/**
 * Validate positive integer
 */
export function validatePositiveInt(
  input: string,
  min: number = 1,
  max?: number
): { valid: boolean; value?: number; error?: string } {
  const num = parseInt(input.trim());
  
  if (isNaN(num)) {
    return { valid: false, error: 'Harus berupa angka' };
  }
  
  if (num < min) {
    return { valid: false, error: `Minimum ${min}` };
  }
  
  if (max !== undefined && num > max) {
    return { valid: false, error: `Maximum ${max}` };
  }
  
  return { valid: true, value: num };
}

/**
 * Validate not empty text
 */
export function validateNotEmpty(
  input: string,
  maxLength: number = 1000
): { valid: boolean; value?: string; error?: string } {
  const trimmed = input.trim();
  
  if (!trimmed) {
    return { valid: false, error: 'Input tidak boleh kosong' };
  }
  
  if (trimmed.length > maxLength) {
    return { valid: false, error: `Maximum ${maxLength} karakter` };
  }
  
  return { valid: true, value: trimmed };
}

/**
 * Generic response helper untuk success message
 */
export async function sendSuccessReply(
  ctx: Context,
  message: string,
  emoji: string = ICONS.success
) {
  await ctx.reply(`${emoji} ${message}`, { parse_mode: 'HTML' });
}

/**
 * Generic response helper untuk error message
 */
export async function sendErrorReply(
  ctx: Context,
  message: string,
  emoji: string = ICONS.failed
) {
  await ctx.reply(`${emoji} <b>Error</b>\n${message}`, { parse_mode: 'HTML' });
}

/**
 * Update userbot dan send success response
 */
export async function updateAndRespond(
  ctx: Context,
  userId: number,
  userbotId: string,
  updateFn: (u: any) => any,
  successMessage: string,
  nextMenuFn: (ctx: Context) => Promise<void>
) {
  try {
    const updated = await jsonDb.updateUserbot(userbotId, updateFn);
    if (!updated) {
      throw new BotError('NOT_FOUND', 'Userbot tidak ditemukan');
    }
    
    await sendSuccessReply(ctx, successMessage);
    await nextMenuFn(ctx);
  } catch (error) {
    logger.error(error, 'Failed to update userbot');
    await sendErrorReply(ctx, (error as Error).message);
  }
}

/**
 * Update global settings dan send success response
 */
export async function updateGlobalAndRespond(
  ctx: Context,
  userId: number,
  updateFn: (s: any) => any,
  successMessage: string,
  nextMenuFn: (ctx: Context) => Promise<void>
) {
  try {
    const updated = await jsonDb.updateGlobalSettings(updateFn);
    
    await sendSuccessReply(ctx, successMessage);
    await nextMenuFn(ctx);
  } catch (error) {
    logger.error(error, 'Failed to update global settings');
    await sendErrorReply(ctx, (error as Error).message);
  }
}

/**
 * Format dan log operation
 */
export function logOperation(
  userId: number,
  operation: string,
  details: Record<string, any> = {}
) {
  logger.info(
    { userId, operation, ...details },
    `User operation: ${operation}`
  );
}

/**
 * Clean user state dan delete
 */
export function clearUserState(userId: number) {
  // This will be handled in input.router
  // Just a helper to document the pattern
}

/**
 * Validate day range (untuk backup day selection)
 */
export function validateDayInput(
  input: string
): { valid: boolean; value?: string; error?: string } {
  const trimmed = input.trim();
  
  if (trimmed === '*') {
    return { valid: true, value: '*' };
  }
  
  const num = parseInt(trimmed);
  
  if (isNaN(num)) {
    return { valid: false, error: 'Harus * atau angka 1-31' };
  }
  
  if (num < 1 || num > 31) {
    return { valid: false, error: 'Angka harus 1-31' };
  }
  
  return { valid: true, value: trimmed };
}

/**
 * Retry helper dengan exponential backoff
 */
export async function retryOperation<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  initialDelay: number = 1000
): Promise<T> {
  let lastError: Error;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error as Error;
      
      if (attempt < maxRetries - 1) {
        const delay = initialDelay * Math.pow(2, attempt);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  throw lastError!;
}

/**
 * Safe operation dengan timeout
 */
export async function withTimeout<T>(
  operation: Promise<T>,
  timeoutMs: number = 30000
): Promise<T> {
  return Promise.race([
    operation,
    new Promise<T>((_, reject) =>
      setTimeout(
        () => reject(new BotError('TIMEOUT', `Operasi timeout setelah ${timeoutMs}ms`)),
        timeoutMs
      )
    )
  ]);
}

/**
 * Convert string ke boolean safely
 */
export function parseBoolean(value: string): boolean {
  return value.toLowerCase() === 'true' || value === '1' || value === 'yes';
}

/**
 * Get userbot with error handling
 */
export async function getUserbot(userbotId: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === userbotId);
  
  if (!userbot) {
    throw new BotError('NOT_FOUND', `Userbot dengan ID ${userbotId} tidak ditemukan`);
  }
  
  return userbot;
}

/**
 * Safely update userbot dengan validation
 */
export async function safeUpdateUserbot(
  userbotId: string,
  updateFn: (u: any) => any
) {
  const userbot = await getUserbot(userbotId);
  const updated = await jsonDb.updateUserbot(userbotId, updateFn);
  
  if (!updated) {
    throw new BotError('OPERATION_FAILED', 'Gagal menyimpan perubahan');
  }
  
  return updated;
}
