/**
 * Comprehensive error handling and validation utilities for bot operations
 */

import type { Context } from 'telegraf';
import { ICONS, Format } from './format.util';
import pino from 'pino';

const logger = pino({ level: 'info' });

export type ErrorCode = 
  | 'INVALID_INPUT'
  | 'INVALID_FORMAT'
  | 'NOT_FOUND'
  | 'ALREADY_EXISTS'
  | 'UNAUTHORIZED'
  | 'OPERATION_FAILED'
  | 'TIMEOUT'
  | 'RATE_LIMIT'
  | 'SERVER_ERROR'
  | 'VALIDATION_ERROR';

interface ErrorResponse {
  code: ErrorCode;
  message: string;
  details?: string;
}

export class BotError extends Error {
  constructor(
    public code: ErrorCode,
    message: string,
    public details?: string
  ) {
    super(message);
    this.name = 'BotError';
  }
}

/**
 * Validation utilities
 */
export const Validators = {
  /**
   * Validate telegram user ID
   */
  userId: (id: any): id is number => {
    return typeof id === 'number' && id > 0;
  },

  /**
   * Validate chat ID (positive or negative)
   */
  chatId: (id: any): id is number | string => {
    if (typeof id === 'number') return id !== 0;
    if (typeof id === 'string') return /^-?\d+$/.test(id) || id.startsWith('@');
    return false;
  },

  /**
   * Validate username format
   */
  username: (username: string): boolean => {
    return /^@?[a-zA-Z0-9_]{5,32}$/.test(username.replace(/^@/, ''));
  },

  /**
   * Validate phone number format
   */
  phone: (phone: string): boolean => {
    return /^\+?[1-9]\d{1,14}$/.test(phone.replace(/\s+/g, ''));
  },

  /**
   * Validate time format HH:MM
   */
  timeFormat: (time: string): boolean => {
    return /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(time);
  },

  /**
   * Validate timezone format
   */
  timezone: (tz: string): boolean => {
    try {
      new Intl.DateTimeFormat('en-US', { timeZone: tz });
      return true;
    } catch {
      return false;
    }
  },

  /**
   * Validate delay value in seconds
   */
  delay: (value: any, min: number = 1, max: number = 3600): boolean => {
    const num = parseInt(value);
    return !isNaN(num) && num >= min && num <= max;
  },

  /**
   * Validate URL
   */
  url: (url: string): boolean => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  },

  /**
   * Validate session string format
   */
  sessionString: (session: string): boolean => {
    // Basic session string validation
    return session.length > 100 && !session.includes('\n');
  },

  /**
   * Validate JSON
   */
  json: (str: string): boolean => {
    try {
      JSON.parse(str);
      return true;
    } catch {
      return false;
    }
  },

  /**
   * Check if string is not empty
   */
  notEmpty: (str: any): str is string => {
    return typeof str === 'string' && str.trim().length > 0;
  }
};

/**
 * Error response formatter
 */
export class ErrorFormatter {
  static format(error: Error | BotError | unknown): string {
    if (error instanceof BotError) {
      return this.botError(error);
    }

    if (error instanceof Error) {
      return this.standardError(error);
    }

    return `${ICONS.failed} <b>Unknown Error</b>\n${Format.code(String(error))}`;
  }

  private static botError(error: BotError): string {
    const messages: Record<ErrorCode, (msg: string) => string> = {
      'INVALID_INPUT': (msg) => `${ICONS.failed} <b>Invalid Input</b>\n${msg}`,
      'INVALID_FORMAT': (msg) => `${ICONS.failed} <b>Invalid Format</b>\n${msg}`,
      'NOT_FOUND': (msg) => `${ICONS.failed} <b>Not Found</b>\n${msg}`,
      'ALREADY_EXISTS': (msg) => `${ICONS.warning} <b>Already Exists</b>\n${msg}`,
      'UNAUTHORIZED': (msg) => `${ICONS.failed} <b>Unauthorized</b>\n${msg}`,
      'OPERATION_FAILED': (msg) => `${ICONS.failed} <b>Operation Failed</b>\n${msg}`,
      'TIMEOUT': (msg) => `${ICONS.warning} <b>Operation Timeout</b>\n${msg}`,
      'RATE_LIMIT': (msg) => `${ICONS.warning} <b>Rate Limited</b>\n${msg}`,
      'SERVER_ERROR': (msg) => `${ICONS.failed} <b>Server Error</b>\n${msg}`,
      'VALIDATION_ERROR': (msg) => `${ICONS.failed} <b>Validation Error</b>\n${msg}`,
    };

    const formatter = messages[error.code] || ((msg) => `${ICONS.failed} <b>Error</b>\n${msg}`);
    let result = formatter(error.message);
    
    if (error.details) {
      result += `\n\n${Format.code(error.details)}`;
    }

    return result;
  }

  private static standardError(error: Error): string {
    const message = error.message || 'Unknown error occurred';
    const name = error.name || 'Error';
    return `${ICONS.failed} <b>${name}</b>\n${message}`;
  }
}

/**
 * Safe operation wrapper
 */
export async function safeOperation<T>(
  operation: () => Promise<T>,
  onError?: (error: Error) => Promise<void>
): Promise<T | null> {
  try {
    return await operation();
  } catch (error) {
    logger.error(error, 'Operation failed');
    if (onError) {
      await onError(error as Error);
    }
    return null;
  }
}

/**
 * Reply with error message (safe)
 */
export async function replyError(ctx: Context, error: Error | BotError | unknown) {
  try {
    const message = ErrorFormatter.format(error);
    // @ts-ignore
    if (ctx.callbackQuery) {
      await ctx.answerCbQuery(
        typeof error === 'string' ? error.substring(0, 200) : 'An error occurred',
        true
      ).catch(() => {});
      await ctx.editMessageText(message, { parse_mode: 'HTML' }).catch(() => {
        return ctx.reply(message, { parse_mode: 'HTML' });
      });
    } else {
      await ctx.reply(message, { parse_mode: 'HTML' });
    }
  } catch (err) {
    logger.error(err, 'Failed to reply error');
  }
}

/**
 * Parse telegram link/username/ID to chat ID
 */
export function parseTelegramIdentifier(input: string): { type: 'username' | 'id' | 'url', value: string } | null {
  const trimmed = input.trim();

  // Check if it's a URL
  if (trimmed.includes('t.me/')) {
    const match = trimmed.match(/t\.me\/([a-zA-Z0-9_]+)/);
    if (match) {
      const identifier = match[1];
      // Check if it's a numeric ID (group)
      return {
        type: identifier.match(/^\d+$/) ? 'id' : 'username',
        value: identifier.match(/^\d+$/) ? identifier : '@' + identifier
      };
    }
  }

  // Check if it's a username
  if (trimmed.startsWith('@')) {
    return { type: 'username', value: trimmed };
  }

  // Check if it's a numeric ID
  if (/^-?\d+$/.test(trimmed)) {
    return { type: 'id', value: trimmed };
  }

  return null;
}

/**
 * Rate limit tracker
 */
export class RateLimiter {
  private requests = new Map<string, number[]>();
  private readonly windowMs: number;
  private readonly maxRequests: number;

  constructor(windowMs: number = 60000, maxRequests: number = 10) {
    this.windowMs = windowMs;
    this.maxRequests = maxRequests;
  }

  isLimited(key: string): boolean {
    const now = Date.now();
    const requests = this.requests.get(key) || [];
    
    // Remove old requests outside the window
    const validRequests = requests.filter(time => now - time < this.windowMs);
    
    if (validRequests.length >= this.maxRequests) {
      return true;
    }

    validRequests.push(now);
    this.requests.set(key, validRequests);
    return false;
  }

  reset(key: string): void {
    this.requests.delete(key);
  }
}

/**
 * Input sanitizer
 */
export const InputSanitizer = {
  /**
   * Sanitize user input to prevent injection
   */
  sanitize(input: string, maxLength: number = 1000): string {
    return input
      .substring(0, maxLength)
      .replace(/[<>]/g, '') // Remove angle brackets
      .trim();
  },

  /**
   * Escape special HTML characters
   */
  escapeHtml(text: string): string {
    const div = { textContent: text, innerHTML: '' };
    div.innerHTML = text;
    return div.textContent;
  },

  /**
   * Normalize whitespace
   */
  normalizeWhitespace(text: string): string {
    return text.replace(/\s+/g, ' ').trim();
  }
};
