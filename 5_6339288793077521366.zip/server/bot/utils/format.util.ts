/**
 * Utility for consistent text formatting in Telegram messages
 * Provides helpers for creating structured, readable bot responses
 */

export const Format = {
  /**
   * Create a horizontal divider line
   * @param length Line length (default: 35)
   */
  divider: (length: number = 35): string => {
    return '━'.repeat(length);
  },

  /**
   * Create a header section with title
   */
  header: (title: string, icon: string = ''): string => {
    const fullTitle = icon ? `${icon} ${title}` : title;
    return `<b>${fullTitle}</b>`;
  },

  /**
   * Create a section with border
   */
  section: (title: string, icon: string = '', content: string = ''): string => {
    const header = Format.header(title, icon);
    return content ? `${header}\n${content}` : header;
  },

  /**
   * Create a list item with nesting
   * @param level Indentation level (0-3)
   * @param label Item label
   * @param value Item value
   * @param isLast Whether this is the last item
   */
  item: (level: number = 0, label: string, value: string = '', isLast: boolean = false): string => {
    const prefixes = ['├─', '│  ├─', '│  │  ├─', '│  │  │  ├─'];
    const lastPrefixes = ['└─', '│  └─', '│  │  └─', '│  │  │  └─'];
    
    const prefix = isLast ? (lastPrefixes[level] || '└─') : (prefixes[level] || '├─');
    
    if (value) {
      return `${prefix} <b>${label}:</b> ${value}`;
    }
    return `${prefix} ${label}`;
  },

  /**
   * Create bold text
   */
  bold: (text: string): string => `<b>${text}</b>`,

  /**
   * Create italic text
   */
  italic: (text: string): string => `<i>${text}</i>`,

  /**
   * Create code block (monospace)
   */
  code: (text: string): string => `<code>${text}</code>`,

  /**
   * Create inline code
   */
  inlineCode: (text: string): string => `<code>${text}</code>`,

  /**
   * Create a status badge
   */
  badge: (status: 'success' | 'error' | 'warning' | 'info', text: string): string => {
    const icons: Record<string, string> = {
      success: '✅',
      error: '❌',
      warning: '⚠️',
      info: 'ℹ️'
    };
    return `${icons[status]} ${text}`;
  },

  /**
   * Create a progress bar
   */
  progressBar: (current: number, total: number, length: number = 10): string => {
    const filled = Math.round((current / total) * length);
    const empty = length - filled;
    return `[${'█'.repeat(filled)}${'░'.repeat(empty)}] ${current}/${total}`;
  },

  /**
   * Format number with locale
   */
  number: (num: number): string => {
    return num.toLocaleString();
  },

  /**
   * Format bytes to human readable
   */
  bytes: (bytes: number): string => {
    const sizes = ['B', 'KB', 'MB', 'GB'];
    if (bytes === 0) return '0 B';
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + sizes[i];
  },

  /**
   * Format time difference (ms) to readable string
   */
  timeDiff: (ms: number): string => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ${hours % 24}h`;
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
  },

  /**
   * Format date to readable string
   */
  date: (timestamp: number): string => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  },

  /**
   * Create a table-like structure
   */
  table: (headers: string[], rows: (string | number)[][], maxWidth: number = 40): string => {
    let result = headers.map(h => `<b>${h}</b>`).join(' | ') + '\n';
    result += '─'.repeat(maxWidth) + '\n';
    result += rows.map(row => row.join(' | ')).join('\n');
    return result;
  },

  /**
   * Create key-value display
   */
  keyValue: (obj: Record<string, any>, level: number = 0): string => {
    const entries = Object.entries(obj);
    return entries.map(([key, value], index) => {
      const isLast = index === entries.length - 1;
      return Format.item(level, key, String(value), isLast);
    }).join('\n');
  }
};

/**
 * Status/state icon constants
 */
export const ICONS = {
  // Status indicators
  online: '🟢',
  offline: '⚪',
  error: '🔴',
  warning: '⚠️',
  success: '✅',
  failed: '❌',
  pending: '⏳',
  paused: '⏸️',
  
  // Activities
  send: '📨',
  broadcast: '📢',
  target: '🎯',
  settings: '⚙️',
  backup: '💾',
  restore: '📥',
  export: '📦',
  import: '📂',
  
  // Information
  info: 'ℹ️',
  stats: '📊',
  list: '📋',
  config: '⚡',
  security: '🔐',
  eye: '👁️',
  
  // Controls
  plus: '➕',
  minus: '➖',
  edit: '✏️',
  delete: '🗑️',
  refresh: '🔄',
  back: '🔙',
  next: '➡️',
  prev: '⬅️',
  home: '🏠',
  
  // Bots
  bot: '🤖',
  telegram: '📱',
  user: '👤',
  group: '👥',
  channel: '📡',
  
  // Time
  timer: '⏱️',
  clock: '🕐',
  calendar: '📅',
  
  // Other
  star: '⭐',
  premium: '💎',
  warning_alt: '⚡',
  link: '🔗',
  search: '🔍',
  scan: '📡',
  code: '💻',
  rocket: '🚀'
};

/**
 * Pre-built status formatters
 */
export const StatusFormatter = {
  userbot: (status: string) => {
    const statusMap: Record<string, string> = {
      'RUNNING': `${ICONS.online} Running`,
      'READY': `${ICONS.offline} Ready`,
      'STOPPED': `${ICONS.offline} Stopped`,
      'ERROR': `${ICONS.error} Error`,
      'OFF_SUBS': `${ICONS.warning} Subscription Expired`
    };
    return statusMap[status] || `${ICONS.offline} Unknown`;
  },

  subscription: (daysLeft: number) => {
    if (daysLeft > 30) return `${ICONS.success} Active (${daysLeft}d)`;
    if (daysLeft > 0) return `${ICONS.warning} Active (${daysLeft}d)`;
    return `${ICONS.failed} Expired`;
  },

  feature: (enabled: boolean, label: string = '') => {
    const base = enabled ? `${ICONS.success} Enabled` : `${ICONS.failed} Disabled`;
    return label ? `${base} • ${label}` : base;
  }
};
