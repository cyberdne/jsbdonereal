import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';

export async function sendSourceMenu(ctx: Context) {
  const text = `${ICONS.download} <b>💾 SOURCE CODE MANAGER</b>
${Format.divider(50)}

<b>📦 EXPORT SCRIPT BOT</b>
${Format.item(1, 'Function', 'Backup & export source code bot ke ZIP')}
${Format.item(1, 'Usage', 'Pilih opsi export sesuai kebutuhan Anda', true)}

<b>🔹 EXPORT OPTIONS</b>
${Format.item(1, '📄 Script Only', 'Hanya file inti tanpa modules & data')}
${Format.item(1, '📁 No Modules', 'Script + data tanpa node_modules')}
${Format.item(1, '💾 No Data', 'Script + modules tanpa folder data')}
${Format.item(1, '📦 Full Backup', 'Semua file lengkap dengan data & modules', true)}

<b>⚙️ CUSTOM OPTIONS</b>
${Format.item(1, '✏️ Name', 'Customize nama file ZIP backup')}
${Format.item(1, '📂 Format', 'Semua output dalam format .zip', true)}

<b>📋 DELIVERY INFO</b>
${Format.item(1, '📨 Delivery', 'File akan dikirim ke chat ini')}
${Format.item(1, '⚡ Speed', 'Waktu processing tergantung ukuran file')}
${Format.item(1, '🔒 Security', 'File hanya dikirim ke user yang request', true)}

<b>🛠️ BACKUP STRATEGY</b>
${Format.item(1, '⏰ Frequency', 'Backup secara berkala (minimum mingguan)')}
${Format.item(1, '💾 Storage', 'Simpan di multiple locations untuk safety')}
${Format.item(1, '🔐 Encryption', 'Recommended: encrypt file sebelum disimpan', true)}

${Format.divider(50)}
<i>💡 Backup secara berkala untuk menjaga keamanan & recovery data script!</i>`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback('📄 Script Only', 'source:script_only'),
      Markup.button.callback('📁 No Modules', 'source:no_modules')
    ],
    [
      Markup.button.callback('💾 No Data', 'source:no_data'),
      Markup.button.callback('📦 Full Backup', 'source:full')
    ],
    [Markup.button.callback('✏️ Custom Name', 'source:custom')],
    [Markup.button.callback(`${ICONS.back} Back`, 'home')]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
