import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendTimerMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const { timer } = userbot.settings;
  const statusEmoji = timer.enabled ? ICONS.online : ICONS.offline;
  const statusText = timer.enabled ? 'Active' : 'Inactive';

  const text = `${ICONS.timer} <b>⏰ SCHEDULER CONFIGURATION</b>
${Format.divider(50)}

${Format.item(1, `${ICONS.bot} Userbot`, Format.bold(userbot.label))}

<b>📊 TIMER STATUS</b>
${Format.item(1, 'Status', `${statusEmoji} ${Format.bold(statusText)}`)}
${Format.item(1, 'Start Time', Format.code(timer.startAt))}
${Format.item(1, 'Stop Time', Format.code(timer.stopAt), true)}

<b>⚙️ BROADCAST SCHEDULE</b>
${Format.item(1, 'Mulai Jam', `Bot mulai broadcast pada ${Format.bold(timer.startAt)}`)}
${Format.item(1, 'Berhenti Jam', `Bot berhenti broadcast pada ${Format.bold(timer.stopAt)}`)}
${Format.item(1, 'Zona Waktu', `${Format.bold(db.globalSettings.timezone)}`, true)}

<b>🎯 FITUR UTAMA</b>
${Format.item(1, 'Jadwal Otomatis', timer.enabled ? '✅ Bot broadcast sesuai jadwal' : '❌ Timer dinonaktifkan', true)}

${Format.divider(50)}
<i>💡 Broadcast akan otomatis on/off berdasarkan jadwal yang Anda set.</i>`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(timer.enabled ? `${ICONS.failed} Disable Timer` : `${ICONS.success} Enable Timer`, `action:toggle_timer:${id}`)],
    [
      Markup.button.callback(`🕐 Set Start Time`, `input:timer_start:${id}`),
      Markup.button.callback(`🕐 Set Stop Time`, `input:timer_stop:${id}`)
    ],
    [Markup.button.callback(`${ICONS.refresh} Refresh`, `menu:timer:${id}`)],
    [Markup.button.callback(`${ICONS.back} Back`, `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
