import type { Context } from 'telegraf';
import { Markup } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS, StatusFormatter } from '../utils/format.util';
import { jsonDb } from '../../storage/db';
import { userbotManager } from '../../userbots/userbot.manager';
import { liveEvents } from '../../utils/live-events';

export async function sendStatsMenu(ctx: Context) {
  const db = await jsonDb.read();
  const userbots = db.userbots;
  
  const totalSent = userbots.reduce((acc, u) => acc + u.stats.sent, 0);
  const totalFailed = userbots.reduce((acc, u) => acc + u.stats.failed, 0);
  const totalSkipped = userbots.reduce((acc, u) => acc + u.stats.skipped, 0);
  const totalTargets = userbots.reduce((acc, u) => acc + u.settings.targets.length, 0);
  
  // Get live broadcast data
  const activeBroadcasts = liveEvents.getAllBroadcasts();
  const liveSent = activeBroadcasts.reduce((sum, b) => sum + b.sent, 0);
  
  const statusCounts = {
    running: userbots.filter(u => u.status === 'RUNNING').length,
    stopped: userbots.filter(u => u.status === 'STOPPED').length,
    ready: userbots.filter(u => u.status === 'READY').length,
    error: userbots.filter(u => u.status === 'ERROR').length,
    offSubs: userbots.filter(u => u.status === 'OFF_SUBS').length,
  };

  const successRate = totalSent + totalFailed > 0 
    ? ((totalSent / (totalSent + totalFailed)) * 100).toFixed(2)
    : '0';

  const pingInfo: string[] = [];
  for (const u of userbots.slice(0, 5)) {
    const client = userbotManager.getClient(u.id);
    if (client) {
      try {
        const ping = await client.ping();
        pingInfo.push(Format.item(1, u.label, `<b>${ping}ms</b>`));
        await jsonDb.updateUserbot(u.id, ub => {
          ub.stats.lastPingMs = ping;
          return ub;
        });
      } catch (e) {
        pingInfo.push(Format.item(1, u.label, 'Error', true));
      }
    }
  }

  const text = `${ICONS.stats} <b>📊 SYSTEM STATISTICS</b>
${Format.divider(50)}

<b>🤖 USERBOT STATUS</b>
${Format.item(1, `${ICONS.online} Aktif`, `<b>${statusCounts.running}</b> bot`)}
${Format.item(1, `${ICONS.offline} Ready`, `<b>${statusCounts.ready}</b> bot`)}
${Format.item(1, '⏹️ Berhenti', `<b>${statusCounts.stopped}</b> bot`)}
${Format.item(1, `${ICONS.warning} Expired`, `<b>${statusCounts.offSubs}</b> bot`)}
${Format.item(1, `${ICONS.error} Error`, `<b>${statusCounts.error}</b> bot`, true)}

<b>📈 MESSAGE STATISTICS</b>
${Format.item(1, `✅ Terkirim`, `<b>${Format.number(totalSent)}</b> pesan`)}
${Format.item(1, `❌ Gagal`, `<b>${Format.number(totalFailed)}</b> pesan`)}
${Format.item(1, '⏭️ Dilewati', `<b>${Format.number(totalSkipped)}</b> pesan`)}
${Format.item(1, `${ICONS.target} Total Target`, `<b>${Format.number(totalTargets)}</b> grup`)}
${Format.item(1, '🎯 Success Rate', `<b>${successRate}%</b>`, true)}

<b>🔴 LIVE BROADCASTS</b>
${activeBroadcasts.length > 0 
  ? Format.item(1, '🔄 Running', `<b>${activeBroadcasts.length}</b> broadcast`) + '\n' +
    Format.item(1, '📤 Live Sent', `<b>${Format.number(liveSent)}</b> pesan`, true)
  : Format.item(1, '💤 Status', 'Idle - No broadcasts', true)}

<b>⚡ CONNECTION PING</b>
${pingInfo.length > 0 ? pingInfo.join('\n') + Format.item(1, '...', '5 top userbots', true) : Format.item(1, 'Offline', 'Tidak ada userbot terkoneksi', true)}

${Format.divider(50)}`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(`${ICONS.refresh} Refresh`, 'menu:stats')],
    [Markup.button.callback(`${ICONS.export} Generate Excel Report`, 'action:report_generate')],
    [Markup.button.callback(`${ICONS.back} Back`, 'home')]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
