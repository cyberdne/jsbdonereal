import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendAutoReadChatMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const settings = userbot.settings.autoReadChat;
  const statusEmoji = settings?.enabled ? ICONS.online : ICONS.offline;
  const groupEmoji = settings?.readGroups ? ICONS.success : ICONS.failed;
  const pmEmoji = settings?.readPrivate ? ICONS.success : ICONS.failed;

  const text = `${ICONS.search} <b>👀 AUTO READ CHAT</b>
${Format.divider(50)}

${Format.item(1, `${ICONS.bot} Userbot`, Format.bold(userbot.label))}

<b>ℹ️ FEATURE DESCRIPTION</b>
${Format.item(1, 'Function', 'Otomatis membaca semua pesan grup & PM')}
${Format.item(1, 'Purpose', 'Marks semua messages sebagai read')}
${Format.item(1, 'Benefit', '✅ Terlihat selalu aktif & responsive', true)}

<b>📊 FEATURE CONFIGURATION</b>
${Format.item(1, 'Status', `${statusEmoji} ${settings?.enabled ? '✅ Aktif' : '❌ Nonaktif'}`)}
${Format.item(1, 'Read Groups', `${groupEmoji} ${settings?.readGroups ? 'Enabled' : 'Disabled'}`)}
${Format.item(1, 'Read Private', `${pmEmoji} ${settings?.readPrivate ? 'Enabled' : 'Disabled'}`, true)}

<b>🔄 CARA KERJA</b>
${Format.item(1, '1️⃣ Monitor', 'Bot monitor semua incoming messages')}
${Format.item(1, '2️⃣ Auto Read', 'Automatically marks message as read')}
${Format.item(1, '📍 Scope', settings?.readGroups ? 'Groups + Private' : settings?.readPrivate ? 'Private Only' : 'All Disabled')}
${Format.item(1, '👁️ Effect', 'Sender akan lihat pesan Anda sudah read', true)}

<b>💡 BENEFITS & USE CASES</b>
${Format.item(1, '🟢 Profile', 'Tampil selalu online & responsive')}
${Format.item(1, '📞 Support', 'Ideal untuk customer service bots')}
${Format.item(1, '🔐 Privacy', 'Hide inactive status dari contact')}
${Format.item(1, '💼 Professional', 'Look more engaged & professional', true)}

<b>⚠️ IMPORTANT CONSIDERATIONS</b>
${Format.item(1, '👁️ Notice', 'Akan terlihat online di setiap chat')}
${Format.item(1, '📊 Data', 'Bot akan read SEMUA pesan otomatis')}
${Format.item(1, '🔓 Privacy', 'Setiap orang tahu bot aktif always', true)}

${Format.divider(50)}
<i>💡 Gunakan untuk maintain professional presence & responsiveness.</i>`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(settings?.enabled ? `${ICONS.failed} Disable All` : `${ICONS.success} Enable All`, `action:toggle_auto_read:${id}`)],
    [
      Markup.button.callback(settings?.readGroups ? `✅ Groups` : `⬜ Groups`, `action:toggle_read_groups:${id}`),
      Markup.button.callback(settings?.readPrivate ? `✅ Private` : `⬜ Private`, `action:toggle_read_private:${id}`)
    ],
    [Markup.button.callback(`${ICONS.rocket} Execute Now`, `action:execute_auto_read:${id}`)],
    [Markup.button.callback(`${ICONS.back} Back`, `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
