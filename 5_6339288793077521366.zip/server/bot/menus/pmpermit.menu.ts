import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendPmPermitMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const { pmPermit } = userbot;
  const statusEmoji = pmPermit.enabled ? ICONS.online : ICONS.offline;
  const statusText = pmPermit.enabled ? 'Protect Active' : 'Protect Inactive';
  const templateStatus = pmPermit.template ? 'Custom Template' : 'Default Response';

  const text = `${ICONS.shield} <b>🛡️ PM PERMIT PROTECTION</b>
${Format.divider(50)}

${Format.item(1, `${ICONS.bot} Userbot`, Format.bold(userbot.label))}

<b>🔒 PROTECTION STATUS</b>
${Format.item(1, 'Status', `${statusEmoji} ${Format.bold(statusText)}`)}
${Format.item(1, 'Users Whitelist', `<b>${pmPermit.allowed.length}</b> user`)}
${Format.item(1, 'Protection Mode', pmPermit.enabled ? '✅ Aktif' : '❌ Nonaktif', true)}

<b>💬 AUTO-REPLY TEMPLATE</b>
${Format.item(1, 'Type', `${Format.bold(templateStatus)}`)}
${Format.item(1, 'Content', pmPermit.template ? Format.code(pmPermit.template.substring(0, 50) + '...') : Format.italic('Default response'), true)}

<b>🔄 CARA KERJA</b>
${Format.item(1, '1️⃣ Terima', 'Bot menerima PM dari pengguna')}
${Format.item(1, '2️⃣ Validasi', 'Cek apakah user ada di whitelist')}
${Format.item(1, '3️⃣ Balas', pmPermit.enabled ? 'Jika tidak di-whitelist → balas dengan template' : 'Terima semua PM tanpa filter', true)}

<b>✨ KEUNTUNGAN</b>
${Format.item(1, 'Spam Protection', 'Blokir pesan dari orang tidak dikenal')}
${Format.item(1, 'Automatis', 'Response otomatis tanpa input manual', true)}

${Format.divider(50)}
<i>💡 User di whitelist selalu bisa chat tanpa terganggu auto-reply.</i>`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(pmPermit.enabled ? '⏸️ Nonaktifkan' : '▶️ Aktifkan', `action:toggle_pmpermit:${id}`)],
    [Markup.button.callback('📝 Set Template', `input:pm_template:${id}`)],
    [
      Markup.button.callback('➕ Tambah User', `input:pm_allow:${id}`),
      Markup.button.callback('🗑️ Clear WL', `action:clear_pm_allowed:${id}`)
    ],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
