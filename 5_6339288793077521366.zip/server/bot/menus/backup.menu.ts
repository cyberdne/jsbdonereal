import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendBackupMenu(ctx: Context) {
  const db = await jsonDb.read();
  const backupSettings = db.backupSettings || {
    enabled: false,
    channelId: null,
    schedule: { day: '*', hour: '00', minute: '00' }
  };
  
  const statusEmoji = backupSettings.enabled ? ICONS.online : ICONS.offline;
  const scheduleText = backupSettings.enabled 
    ? `Every ${backupSettings.schedule.day === '*' ? 'day' : `day ${backupSettings.schedule.day}`} at ${backupSettings.schedule.hour}:${backupSettings.schedule.minute}`
    : 'Inactive';
  
  const text = `${ICONS.save} <b>💾 BACKUP & RESTORE MANAGER</b>
${Format.divider(50)}

<b>⚙️ AUTO BACKUP CONFIGURATION</b>
${Format.item(1, 'Status', `${statusEmoji} ${backupSettings.enabled ? '✅ Aktif' : '❌ Nonaktif'}`)}
${Format.item(1, 'Channel Target', Format.code(backupSettings.channelId ? backupSettings.channelId.toString() : 'Not Set'))}
${Format.item(1, 'Schedule', scheduleText, true)}

<b>📝 AUTO BACKUP DESCRIPTION</b>
${Format.item(1, 'Function', 'Backup database otomatis sesuai jadwal')}
${Format.item(1, 'Target', 'File backup dikirim ke channel Telegram')}
${Format.item(1, 'Benefit', '🛡️ Proteksi data dari kehilangan & crash', true)}

<b>🔧 MANUAL ACTIONS</b>
${Format.item(1, 'Now', 'Buat backup segera tanpa menunggu jadwal')}
${Format.item(1, 'Restore', 'Pulihkan data dari backup sebelumnya', true)}

<b>⚡ QUICK SETUP</b>
${Format.item(1, '1️⃣ Set Channel', 'Tentukan target channel untuk auto backup')}
${Format.item(1, '2️⃣ Configure', 'Atur jadwal backup (hari & waktu)')}
${Format.item(1, '3️⃣ Enable', 'Aktifkan auto backup')}
${Format.item(1, '✅ Done', 'Sistem backup otomatis sesuai jadwal', true)}

${Format.divider(50)}
<i>💾 Saran: Backup setiap hari untuk keamanan maksimal!</i>`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback(backupSettings.enabled ? `${ICONS.failed} Disable Auto` : `${ICONS.success} Enable Auto`, 'backup:toggle'),
      Markup.button.callback('📺 Set Channel', 'backup:set_channel')
    ],
    [
      Markup.button.callback('⏰ Set Time', 'backup:set_schedule'),
      Markup.button.callback('📅 Set Day', 'backup:set_day')
    ],
    [
      Markup.button.callback(`${ICONS.save} Backup Now`, 'backup:now'),
      Markup.button.callback(`${ICONS.refresh} Restore`, 'backup:restore')
    ],
    [Markup.button.callback(`${ICONS.back} Back`, 'home')]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
