import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendMainMenu(ctx: Context) {
  const db = await jsonDb.read();
  const totalUserbots = db.userbots.length;
  const activeUserbots = db.userbots.filter(u => u.status === 'RUNNING').length;
  const readyUserbots = db.userbots.filter(u => u.status === 'READY').length;
  const errorUserbots = db.userbots.filter(u => u.status === 'ERROR').length;
  const totalSent = db.userbots.reduce((sum, u) => sum + u.stats.sent, 0);
  const totalTargets = db.userbots.reduce((sum, u) => sum + u.settings.targets.length, 0);
  
  const text = `${ICONS.rocket} <b>JASEB Bot Control Panel</b>
<i>Advanced Multi-Userbot Broadcast Platform</i>
${Format.divider(50)}

<b>📊 DASHBOARD OVERVIEW</b>
${Format.item(1, `${ICONS.online} Active`, `<b>${activeUserbots}</b> bot`)}
${Format.item(1, `${ICONS.offline} Ready`, `<b>${readyUserbots}</b> bot`)}
${Format.item(1, `${ICONS.error} Error`, `<b>${errorUserbots}</b> bot`)}
${Format.item(1, `${ICONS.bot} Total`, `<b>${totalUserbots}</b> bot`, true)}

<b>📈 ACTIVITY METRICS</b>
${Format.item(1, `${ICONS.send} Messages Sent`, `<b>${Format.number(totalSent)}</b>`)}
${Format.item(1, `${ICONS.target} Broadcast Targets`, `<b>${Format.number(totalTargets)}</b>`, true)}

<b>🔧 SYSTEM STATUS</b>
${Format.item(1, '💾 Memory', '<b>Healthy</b>')}
${Format.item(1, '🗄️ Database', '<b>Synced</b>')}
${Format.item(1, `⏰ Timezone`, `<b>${db.globalSettings?.timezone || 'UTC'}</b>`, true)}

${Format.divider(50)}

<b>📱 MAIN MENU</b>
Pilih kategori untuk mengelola bot Anda.`;

  const keyboard = Markup.inlineKeyboard([
    // Row 1: Main Controls
    [
      Markup.button.callback(`${ICONS.bot} Manage Bots`, 'menu:userbots'),
      Markup.button.callback(`${ICONS.stats} Statistics`, 'menu:stats')
    ],
    // Row 2: Monitor & Configuration
    [
      Markup.button.callback(`${ICONS.eye} Live Monitor`, 'monitor_active'),
      Markup.button.callback(`${ICONS.settings} Global Settings`, 'menu:settings')
    ],
    // Row 3: Data Management
    [
      Markup.button.callback(`${ICONS.backup} Backup`, 'menu:backup'),
      Markup.button.callback(`${ICONS.export} Export`, 'menu:source')
    ],
    // Row 4: Utility
    [
      Markup.button.callback(`${ICONS.warning_alt} Clear Cache`, 'action:clear_cache'),
      Markup.button.callback(`${ICONS.code} Monitor Info`, 'action:monitor_info')
    ]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}

function repeat(str: string, count: number): string {
  return str.repeat(count);
}
