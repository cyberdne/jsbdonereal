import { Telegraf } from 'telegraf';
import { ENV } from '../config/env';
import { userbotManager } from '../userbots/userbot.manager';
import { sendMainMenu } from './menus/main.menu';
import { handleCallback } from './routers/callback.router';
import { handleInput } from './routers/input.router';
import pino from 'pino';

const logger = pino({ level: 'info' });

export type UserStateStep = 
  | 'IDLE' 
  | 'PHONE_LOGIN_NUMBER' 
  | 'PHONE_LOGIN_CODE' 
  | 'PHONE_LOGIN_PASSWORD'
  | 'ASK_BUYER_ID'
  | 'ADD_SESSION_STRING'
  | 'ASK_BUYER_ID_SESSION'
  | 'SET_REG_TEXT' 
  | 'SET_WATERMARK'
  | 'AWAIT_FORWARD'
  | 'SET_FORWARD_CHAT'
  | 'SET_FORWARD_MSG_ID'
  | 'ADD_TARGET_MANUAL' 
  | 'SCAN_CHANNEL' 
  | 'SEARCH_KEYWORD'
  | 'SET_TIMER_START'
  | 'SET_TIMER_STOP'
  | 'SET_PM_TEMPLATE'
  | 'ADD_PM_ALLOW'
  | 'SET_INSTANT_DELAY'
  | 'SET_SEQ_DELAY'
  | 'EXTEND_SUBSCRIPTION'
  | 'ADD_AUTOREPLY_KEYWORD'
  | 'SET_AUTOREPLY_TEXT'
  | 'GLOBAL_INSTANT_DELAY'
  | 'GLOBAL_SEQ_DELAY'
  | 'GLOBAL_MAX_TARGETS'
  | 'GLOBAL_JOIN_DELAY'
  | 'GLOBAL_WATERMARK'
  | 'GLOBAL_ADD_BLACKLIST'
  | 'GLOBAL_SET_TIMEZONE'
  | 'SET_BACKUP_CHANNEL'
  | 'SET_BACKUP_TIME'
  | 'SET_BACKUP_DAY'
  | 'ADD_BC_TARGET'
  | 'SET_BC_MESSAGE'
  | 'SOURCE_CUSTOM_NAME'
  | 'BPM_MESSAGE'
  | 'AUTO_LEAVE_DAYS'
  | 'CLEAR_CHAT_DAYS';

export interface UserState {
  step: UserStateStep;
  temp?: any;
}

export class JasebBot {
  public bot: Telegraf | undefined;
  public userStates = new Map<number, UserState>();

  constructor() {
    if (ENV.BOT_TOKEN) {
      this.bot = new Telegraf(ENV.BOT_TOKEN);
      this.setupMiddleware();
      this.setupHandlers();
    } else {
      logger.warn('BOT_TOKEN not set, bot functionality disabled');
    }
  }

  private setupMiddleware() {
    if (!this.bot) return;

    this.bot.use(async (ctx, next) => {
      const userId = ctx.from?.id.toString();
      if (!userId || !ENV.OWNER_IDS.includes(userId)) {
        return;
      }
      return next();
    });
  }

  private setupHandlers() {
    if (!this.bot) return;

    this.bot.command('start', (ctx) => sendMainMenu(ctx));

    this.bot.command('add_session', async (ctx) => {
      // @ts-ignore
      const session = ctx.message.text.split(' ').slice(1).join(' ');
      if (!session) {
        return ctx.reply('Usage: /add_session <string_session>\n\nAtau gunakan menu: /start > Userbots > Tambah Userbot');
      }
      
      this.userStates.set(ctx.from!.id, { step: 'ADD_SESSION_STRING', temp: { pendingSession: session } });
      ctx.reply('⏳ Verifikasi session...');
    });

    this.bot.on('callback_query', (ctx) => handleCallback(ctx));
    this.bot.on('message', (ctx) => handleInput(ctx));

    this.bot.catch((err: any) => {
      logger.error({ err }, 'Bot Error');
    });
  }

  async launch() {
    if (!this.bot) {
      logger.warn('Cannot launch bot: No token provided');
      return;
    }

    await userbotManager.loadAll();
    
    this.bot.launch(() => {
      logger.info('Telegram Bot started');
    });
    
    process.once('SIGINT', () => this.bot?.stop('SIGINT'));
    process.once('SIGTERM', () => this.bot?.stop('SIGTERM'));
  }
}

export const jasebBot = new JasebBot();
