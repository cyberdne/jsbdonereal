import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { BotStatusSchema } from "@shared/schema";

export function useStats() {
  return useQuery({
    queryKey: [api.stats.get.path],
    queryFn: async () => {
      const res = await fetch(api.stats.get.path);
      if (!res.ok) throw new Error("Failed to fetch stats");
      const data = await res.json();
      return BotStatusSchema.parse(data);
    },
    refetchInterval: 5000, // Refresh every 5 seconds for live feel
  });
}
