import { useStats } from "@/hooks/use-stats";
import { StatsCard } from "@/components/StatsCard";
import { 
  Activity, 
  Users, 
  Zap, 
  Send, 
  Clock, 
  RefreshCw,
  Server,
  ShieldCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";

export default function Dashboard() {
  const { data: stats, isLoading, error, refetch, isRefetching } = useStats();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  if (error) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-background p-4 text-center">
        <Server className="h-16 w-16 text-destructive/50 mb-4" />
        <h2 className="text-2xl font-bold text-foreground">Connection Error</h2>
        <p className="mt-2 text-muted-foreground max-w-md">
          Unable to connect to the JASEB Service. The bot might be offline or unreachable.
        </p>
        <Button onClick={() => refetch()} className="mt-6" variant="outline">
          Try Again
        </Button>
      </div>
    );
  }

  // Calculate formatted uptime
  const uptimeString = stats 
    ? formatDistanceToNow(Date.now() - (stats.uptime * 1000)) 
    : "--";

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900/20 via-background to-background p-4 sm:p-6 lg:p-8 font-sans">
      <div className="mx-auto max-w-7xl">
        
        {/* Header */}
        <div className="mb-10 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-3"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/20 text-primary ring-1 ring-primary/50">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                <span className="text-gradient-primary">JASEB</span> Monitor
              </h1>
            </motion.div>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="mt-2 text-muted-foreground"
            >
              Real-time telemetry and status overview
            </motion.p>
          </div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <Button
              onClick={() => refetch()}
              disabled={isLoading || isRefetching}
              className="group relative overflow-hidden rounded-xl bg-secondary/50 border border-white/5 hover:bg-secondary transition-all"
              variant="ghost"
            >
              <RefreshCw 
                className={`mr-2 h-4 w-4 transition-transform duration-700 ${
                  isRefetching ? "animate-spin" : "group-hover:rotate-180"
                }`} 
              />
              {isRefetching ? "Syncing..." : "Refresh Data"}
            </Button>
          </motion.div>
        </div>

        {/* Content */}
        {isLoading ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-40 rounded-2xl bg-white/5 animate-pulse" />
            ))}
          </div>
        ) : (
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4"
          >
            <motion.div variants={item} className="sm:col-span-2 lg:col-span-4">
               <div className="mb-6 overflow-hidden rounded-3xl border border-white/5 bg-card/30 backdrop-blur-xl p-1 shadow-2xl">
                 <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-500/10 via-purple-500/5 to-background p-8 sm:p-10">
                   <div className="relative z-10 flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
                     <div>
                       <div className="flex items-center gap-2 text-sm font-medium text-indigo-400">
                         <span className="relative flex h-2 w-2">
                           <span className={`absolute inline-flex h-full w-full animate-ping rounded-full ${stats?.status === 'online' ? 'bg-emerald-400' : 'bg-rose-400'} opacity-75`}></span>
                           <span className={`relative inline-flex h-2 w-2 rounded-full ${stats?.status === 'online' ? 'bg-emerald-500' : 'bg-rose-500'}`}></span>
                         </span>
                         System Status
                       </div>
                       <h2 className="mt-2 text-3xl font-bold text-white sm:text-5xl">
                         {stats?.status === 'online' ? 'All Systems Operational' : 'System Offline'}
                       </h2>
                       <p className="mt-2 max-w-xl text-lg text-muted-foreground">
                         The JASEB automated bot network is currently {stats?.status === 'online' ? 'running optimally' : 'experiencing downtime'}. 
                         Monitoring {stats?.userbots_count ?? 0} active agents.
                       </p>
                     </div>
                     <div className="flex items-center justify-center rounded-full bg-white/5 p-6 ring-1 ring-white/10 backdrop-blur-md">
                        <Activity className={`h-12 w-12 ${stats?.status === 'online' ? 'text-emerald-400' : 'text-rose-400'}`} />
                     </div>
                   </div>
                   
                   {/* Background decoration */}
                   <div className="absolute right-0 top-0 -mt-20 -mr-20 h-[500px] w-[500px] rounded-full bg-primary/20 blur-3xl opacity-20 pointer-events-none" />
                 </div>
               </div>
            </motion.div>

            <StatsCard
              title="Total Userbots"
              value={stats?.userbots_count ?? 0}
              icon={Users}
              color="info"
              delay={0.1}
            />
            
            <StatsCard
              title="Active Jobs"
              value={stats?.active_jobs ?? 0}
              icon={Zap}
              color="warning"
              delay={0.2}
            />
            
            <StatsCard
              title="Messages Sent"
              value={stats?.total_sent?.toLocaleString() ?? 0}
              icon={Send}
              color="primary"
              delay={0.3}
            />
            
            <StatsCard
              title="Current Uptime"
              value={uptimeString}
              icon={Clock}
              color="purple"
              delay={0.4}
            />
          </motion.div>
        )}

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-12 text-center"
        >
          <p className="text-sm text-muted-foreground/50">
            JASEB Dashboard v1.0 • Connected to {window.location.hostname}
          </p>
        </motion.div>
      </div>
    </div>
  );
}
