# JASEB Telegram Bot

Bot Telegram Jasa Sebar (Broadcast Service) berbasis Node.js v20.
Didesain untuk dijalankan di VPS atau Panel Pterodactyl.

## Fitur
- Multi-Userbot (String Session & Phone Login)
- Broadcast Instant & Sequential
- File-based Database (JSON) - Aman & Ringan
- Inline Keyboard UI Modern
- Laporan Excel
- Auto-Reply PM Permit
- Target Manager (Scan Group/Channel)

## Instalasi

### 1. Persiapan VPS / Panel
Pastikan server menggunakan **Node.js v20**.

### 2. Clone & Install
```bash
git clone <repo_url> jaseb-bot
cd jaseb-bot
npm install
npm run build
```

### 3. Konfigurasi Environment
Salin `.env.example` menjadi `.env` dan isi variabel yang diperlukan.
```bash
cp .env.example .env
nano .env
```

Isi data berikut:
- `BOT_TOKEN`: Token dari @BotFather.
- `OWNER_IDS`: ID Telegram owner (pisahkan koma jika banyak).
- `API_ID` & `API_HASH`: Dapatkan di https://my.telegram.org (Menu API Development Tools).

### 4. Jalankan Bot
Mode Development:
```bash
npm run dev
```

Mode Production (Pterodactyl/VPS):
```bash
npm start
```

## Struktur Folder
- `server/bot`: Logika utama bot Telegram (UI/Menu).
- `server/userbots`: Manager untuk GramJS userbots.
- `server/jaseb`: Engine broadcast & job runner.
- `server/storage`: Database JSON local.
- `data/`: Tempat penyimpanan `db.json`.

## Catatan Keamanan
- File `data/db.json` berisi session string yang sensitif. Jangan bagikan file ini.
- Gunakan `OWNER_IDS` dengan benar agar orang lain tidak bisa mengakses panel admin.

## Troubleshooting
- **Error 401: Bot Token Required**: Cek `.env` pastikan `BOT_TOKEN` terisi.
- **FloodWait**: Bot otomatis menunggu jika terkena limit Telegram.
