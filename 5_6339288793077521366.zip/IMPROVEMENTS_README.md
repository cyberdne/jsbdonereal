# 🚀 JASEB Control Panel v2.1

**Status**: ✅ Production-Ready with Advanced Features

Telegram Userbot Management & Broadcasting System - Fully Optimized untuk Production Use

---

## 📋 Table of Contents

- [Features](#features)
- [System Requirements](#system-requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [Usage Guide](#usage-guide)
- [Improvements Made](#improvements-made)
- [Production Deployment](#production-deployment)
- [Troubleshooting](#troubleshooting)
- [API Reference](#api-reference)

---

## ✨ Features

### Core Features
- ✅ **Multi-Userbot Management** - Manage multiple Telegram accounts
- ✅ **Broadcast System** - Send messages to multiple targets simultaneously
- ✅ **Smart Targeting** - Add targets manually, scan channels, search keywords
- ✅ **Message Types** - Regular text & forwarded messages
- ✅ **Timer-Based Broadcasting** - Schedule broadcasts during specific hours
- ✅ **Subscription System** - Built-in subscription & expiration tracking
- ✅ **Global Settings** - Centralized configuration for all bots

### Premium Features
- 🌟 **Autopilot** - Fully automated broadcast management
- 🌟 **PM Permit** - Whitelist for personal messages
- 🌟 **Auto-Reply** - Automated keyword-based responses
- 🌟 **Broadcast Private Messages** - Direct PM to targets
- 🌟 **Auto-Leave** - Automatically leave groups after X days
- 🌟 **Auto-Read Chat** - Mark messages as read automatically
- 🌟 **Clear Chat** - Bulk delete old messages
- 🌟 **Premium Emoji** - Custom emoji in messages

### System Features
- ✅ **Statistics Dashboard** - Real-time metrics & analytics
- ✅ **Backup & Restore** - Automated data backup system
- ✅ **Source Code Export** - Export with/without dependencies
- ✅ **Excel Reports** - Generate detailed statistics
- ✅ **Ping Monitoring** - Monitor userbot connection health
- ✅ **Error Tracking** - Comprehensive error logging

---

## 🖥️ System Requirements

### Minimum
- Node.js: >= 18.0.0
- npm: >= 9.0.0
- RAM: 256MB
- Storage: 1GB (for data & backups)
- Network: Stable internet connection

### Recommended
- Node.js: >= 20.0.0
- npm: >= 10.0.0
- RAM: 1GB+
- Storage: 10GB (for extensive backups)
- OS: Linux (Ubuntu 20.04+) atau macOS

### Development
- TypeScript knowledge
- Telegram Bot API understanding
- GramJS library familiarity

---

## 📦 Installation

### 1. Clone Repository
```bash
git clone https://github.com/cyberdne/jsbdonereal.git
cd jsbdonereal
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Setup Environment
```bash
# Copy example env
cp .env.example .env

# Edit configuration
nano .env
```

Required environment variables:
```env
# Bot Configuration
BOT_TOKEN=your_bot_token_here
OWNER_IDS=123456789,987654321  # Comma-separated admin IDs

# Server Configuration
PORT=3000
NODE_ENV=development           # atau production
LOG_LEVEL=info                # debug, info, warn, error

# Data Storage
DATA_DIR=./data

# Optional
API_RATE_LIMIT=100
SESSION_TIMEOUT=3600
```

### 4. Build Project
```bash
npm run build
```

### 5. Initialize Database
```bash
npm run dev &
# Send /start command to bot
# Wait for database to initialize
kill %1
```

### 6. Run Bot
**Development**:
```bash
npm run dev
```

**Production**:
```bash
npm start
```

---

## ⚙️ Configuration

### Bot Token
Dapatkan dari [@BotFather](https://t.me/botfather) di Telegram

### Owner IDs
```bash
# Dapatkan user ID Anda dengan mengirim /start
# Bot akan menampilkan ID Anda di logs
```

### Global Settings
Akses via menu `⚙️ Global Settings`:
- Timezone configuration
- Default delays (instant/sequential)
- Blacklist management
- Watermark template
- Max targets per userbot

### Data Directory
Default: `./data/`
```
data/
├── db.json              # Main database
├── backups/             # Automatic backups
└── exports/             # Exported source code
```

---

## 🎮 Usage Guide

### Starting the Bot

1. **Start Bot Process**
   ```bash
   npm run dev  # atau npm start untuk production
   ```

2. **Open Telegram Bot**
   - Find your bot: `@YourBotUsername`
   - Send `/start` command
   - Main menu akan muncul

### Adding Userbot

**Method 1: Phone Login**
1. Go to `🤖 Userbots` → `➕ Add Userbot`
2. Select `📱 Login via Phone`
3. Enter phone number
4. Enter OTP code
5. If 2FA enabled, enter password
6. Enter Buyer ID
7. Userbot siap digunakan

**Method 2: String Session**
1. Go to `🤖 Userbots` → `➕ Add Userbot`
2. Select `🔑 String Session`
3. Paste session string
4. Enter Buyer ID
5. Userbot siap digunakan

### Setting Up Broadcast

1. **Open Userbot Control Panel**
   - Go to `🤖 Userbots`
   - Select userbot yang diinginkan

2. **Set Message Type**
   - `📝 Regular Text` - ketik pesan
   - `🔄 Forward` - forward dari chat lain

3. **Add Targets**
   - `🎯 Targets` → `➕ Add`
   - Masukkan: `@groupname`, `t.me/group`, atau ID

4. **Configure Settings**
   - `⚙️ Config` - delays & watermark
   - `⏱️ Timer` - schedule waktu broadcast
   - `📊 Broadcast` - spread mode & settings

5. **Start Broadcasting**
   - Tekan ▶️ Start di control panel
   - Monitor di `📊 Statistics`

### Managing Subscriptions

1. Go to Userbot → `💳 Subscription`
2. Extend subscription dengan menambah hari
3. Check subscription status di main panel

### Global Settings

Configure defaults untuk semua userbot:
- `🌍 Timezone` - untuk timer
- `⏱️ Delays` - default instant/sequential
- `🎯 Targets` - max per userbot
- `📝 Watermark` - default text

---

## 🎨 UI/UX Improvements Made

### 1. Format Utility System
- Konsisten visual formatting di semua menu
- Structured text hierarchy
- Better icon usage
- Improved readability

**Before vs After**:
```
BEFORE:
├ 🟢 Running: 5
├ ⚪ Ready: 3

AFTER:
├─ 🟢 Running: <b>5</b>
│  ├─ Active: <b>4</b>
│  └─ Pending: <b>1</b>
```

### 2. Enhanced Menus
Updated menus dengan better presentation:
- `main.menu.ts` - Dashboard dengan metrics
- `userbots.menu.ts` - Better pagination
- `stats.menu.ts` - Success rate calculation
- `global.settings.menu.ts` - Improved organization
- `userbot.control.menu.ts` - Better status indicators

### 3. Navigation Improvements
- Consistent back buttons
- Better menu hierarchy
- Improved pagination
- Status indicators per item

---

## 🛡️ Error Handling & Validation

### Validators Implemented
```typescript
Validators.userId()        // Validate user ID
Validators.chatId()        // Validate chat ID
Validators.username()      // Validate username format
Validators.phone()         // Validate phone number
Validators.timeFormat()    // Validate HH:MM format
Validators.timezone()      // Validate timezone
Validators.sessionString() // Validate session string
```

### Error Handling Features
- Comprehensive error messages
- Structured error responses
- Safe operation wrappers
- Rate limiting framework
- Input sanitization

### Usage Example
```typescript
import { Validators, BotError } from './utils/error.util';

// Validate input
if (!Validators.timeFormat(userInput)) {
  throw new BotError('INVALID_FORMAT', 'Format harus HH:MM');
}

// Safe operation
try {
  await operation();
} catch (error) {
  await replyError(ctx, error);
}
```

---

## 🚀 Production Deployment

### Quick Start
```bash
# 1. Prepare
npm ci --production
npm run build

# 2. Deploy
npm start

# 3. Monitor
tail -f logs/jaseb.log
```

### With Process Manager (PM2)
```bash
# Install PM2
npm install -g pm2

# Start with PM2
pm2 start "npm start" --name "jaseb-bot"

# Setup auto-restart
pm2 startup
pm2 save

# Monitor
pm2 logs jaseb-bot
```

### With Docker
```bash
# Build image
docker build -t jaseb-bot .

# Run container
docker run -d \
  --name jaseb \
  -e BOT_TOKEN=$BOT_TOKEN \
  -e OWNER_IDS=$OWNER_IDS \
  -v $(pwd)/data:/app/data \
  jaseb-bot

# Monitor
docker logs -f jaseb
```

### Pre-Deployment Checklist
- [ ] .env configured correctly
- [ ] BOT_TOKEN is valid
- [ ] OWNER_IDS set
- [ ] Database backed up
- [ ] Dependencies installed
- [ ] Build successful
- [ ] Health check passed

See [PRODUCTION_DEPLOYMENT.md](./PRODUCTION_DEPLOYMENT.md) untuk panduan lengkap.

---

## 🐛 Troubleshooting

### Bot Not Responding
```bash
# Check if running
ps aux | grep node

# Check logs
tail -50 logs/jaseb.log

# Verify token
echo $BOT_TOKEN

# Restart
npm restart
```

### Database Issues
```bash
# Check integrity
node -e "console.log(require('fs').readFileSync('data/db.json'))" | jq .

# Restore from backup
cp data/backups/backup_*.json data/db.json
```

### High Memory Usage
```bash
# Monitor memory
watch -n 5 'ps aux | grep node'

# Check for leaks
node --inspect=0.0.0.0:9229 dist/index.cjs
# Open chrome://inspect
```

### Broadcast Stuck
1. Check network connectivity
2. Verify target groups still exist
3. Check Telegram rate limits
4. Reduce target count per broadcast
5. Use sequential mode

See [OPTIMIZATION_SUMMARY.md](./OPTIMIZATION_SUMMARY.md) untuk troubleshooting lengkap.

---

## 📚 API Reference

### Menu Commands

**Main Navigation**
```
/start              → Show main menu
home                → Back to main menu
```

**Management**
```
menu:userbots       → List all userbots
menu:stats          → View statistics
menu:settings       → Global settings
menu:config:ID      → Userbot config
```

**Broadcasting**
```
menu:bot_broadcast  → Bot broadcast settings
menu:bpm           → Private message broadcast
menu:targets:ID    → Manage targets
```

**Features**
```
menu:timer:ID      → Timer settings
menu:pmpermit:ID   → PM permit settings
menu:autoreply:ID  → Auto reply settings
menu:autopilot:ID  → Autopilot settings
```

### State Management

User states untuk input handling:
```typescript
enum UserStateStep {
  // Login flows
  PHONE_LOGIN_NUMBER,
  PHONE_LOGIN_CODE,
  ADD_SESSION_STRING,
  
  // Settings
  SET_REG_TEXT,
  SET_WATERMARK,
  
  // Broadcasting
  ADD_TARGET_MANUAL,
  SCAN_CHANNEL,
  // ... more states
}
```

---

## 📊 Statistics & Monitoring

### Dashboard Metrics
- Total userbots (Running/Ready/Error)
- Messages sent/failed/skipped
- Active targets count
- System health status
- Last ping response

### Export Reports
- Excel spreadsheet dengan statistics
- Per-userbot breakdown
- Time-range filtering
- Custom report builder

### Monitoring Health
```bash
# Bot uptime
ps -o etime= -p $(pgrep -f "node.*index")

# Database size
du -sh data/db.json

# Backups available
ls -la data/backups/
```

---

## 🔄 Updates & Maintenance

### Regular Tasks
- [ ] Daily: Check logs untuk errors
- [ ] Weekly: Verify backups exist
- [ ] Monthly: Update dependencies
- [ ] Quarterly: Review & clean old data

### Backup Procedure
```bash
# Manual backup
cp -r data data.backup_$(date +%Y-%m-%d)

# Automated (cron)
0 2 * * * /path/to/backup.sh

# Verify restore
cp data/db.json data/db.json.test
```

---

## 🤝 Contributing

Untuk contribute improvements:

1. Fork repository
2. Create feature branch
3. Make changes
4. Add tests
5. Submit pull request

---

## 📄 License

MIT License - See LICENSE file for details

---

## 📞 Support

- **Documentation**: See `.md` files in root
- **Issues**: GitHub Issues
- **Email**: support@jaseb.dev
- **Telegram**: @jaseb_support

---

## 🎯 Roadmap

### v2.2 (Next)
- [ ] Advanced analytics dashboard
- [ ] AI-powered targeting
- [ ] Multi-language support
- [ ] Mobile app integration

### v3.0 (Future)
- [ ] Web UI dashboard
- [ ] API REST endpoints
- [ ] Database optimization
- [ ] Cloud deployment support

---

## ⭐ Credits

Developed dengan passion untuk Telegram automation community.

**Version**: 2.1.0
**Last Updated**: January 31, 2026
**Status**: ✅ Production Ready

---

**Enjoy using JASEB Control Panel! 🚀**
